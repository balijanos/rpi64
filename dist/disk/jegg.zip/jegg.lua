-- Jumping Jegg(Jack) demo
-- 
-- v1.2
-- 

require "sound/jeggmusic"
require "sound/jeggsound"

math.randomseed( os.time() )

local balladofjj = {
	{ "Jumping 'Egg' Jack is quick and bold", 
	  "With skill his story will unfold" },
	{ "THE BALLAD OF JUMPING 'EGG' JACK" },
	{ "A daring explorer named Jack..." },
	{ "Once found a peculiar track..." },
	{ "There were dangers galore..." },
	{ "Even holes in the floor..." },
	{ "So he kept falling flat on his back." },
	{ "Quite soon he got used to the place..." },
	{ "He could jump to escape from the chase..." },
	{ "But without careful thought..." },
	{ "His leaps came to nought..." },
	{ "And he left with a much wider face." },
	{ "Things seemed just as bad as could be..." },
	{ "Hostile faces were all Jack could see..." },
	{ "He tried to stay calm",
	  "And to come to no harm..." },
	{ "But more often got squashed like a flea."},
	{ "By now Jack was in a great flap..." },
	{ "He felt like a rat in a trap..." },
	{ "If only he'd guessed..." },
	{ "That soon he could rest..." },
	{ "After jumping the very last gap." },
	{ "END OF THE BALLAD OF JUMPING 'EGG' JACK" }
}

local level = 0
local lives = 1
local score = 0
local hazards = 0
local hiscore = 50
local intro = 0
local _BKG = {150,150,150}
local _LINE = {32,32,32,100}
local _HOLE = {150,150,150,100}
local _JACK = {48,48,48,255}
local _GRN = {32,200,32,100}
local _BLU = {32,32,200,100}
local _MAG = {200,100,100,100}
local _YEL = {200,200,32,100}

local lines = 9 -- odd number
if HEIGHT<600 then
	lines = 7 -- odd number
end
local linew = 4
local HX = HEIGHT/(lines+1)
local holes = nil -- { xposition, direction, line }
local holew = WIDTH/10
local holestep = 5
local jackspeed = holestep
local jack = { }
local halfjack = 0

-- timing
local tstart = nil

-- sprites
local SP_Jack = nil
local jsprites = {
	rows = 6,
	tiles= 8,
	file = "gfx/dizzy.png",
	speed = { idle=500, left=100, right=100, space=50, fall=100, sick = 250 },	
}

local SP_Enemy = nil
local esprites = {
	rows = 3,
	tiles= 5,
	file = "gfx/enemy1.png",
	speed = 100,	
}

local enemies = {} -- {dir=1, line = 0, x = 0, anim=0, animod=0, w=0}

function setup()   
	level = level + 1	
	lives = lives + 1
	holes = {}
	holes[1] = {1,1,lines}
	holes[2] = {WIDTH-holew,-1,1}
	intro = 1
	
	-- first run
	if tstart == nil then
		musicsetup()
		effectsetup()
	end
	
	-- animation
	tstart = timer()
	SP_Jack = sprite(jsprites.file)
	SP_Jack:setTiles(jsprites.tiles, jsprites.rows)	
		
	jack = { x = WIDTH/2, y=1, anim=0, animod=0, line=0, state = "idle" }
	jack.w, jack.h = SP_Jack:getTileSize()
	halfjack = jack.w/2
	
	SP_Enemy = sprite(esprites.file)
	SP_Enemy:setTiles(esprites.tiles, esprites.rows)
end

function cleanup()
	musiccleanup()
	effectcleanup()
end

function drawlevel()
	background(unpack(_BKG))
	fill(unpack(_LINE))
	for i=0,lines do
		rect(1,i*HX,WIDTH,linew)
	end
	fill(unpack(_HOLE))
	for k,v in ipairs(holes) do
		if v[1] then
			rect(v[1],v[3]*HX,holew,linew)
		end
	end
end

function drawjack(tick)	
	if jack.state == "idle" or jack.state == "left" or jack.state == "right" or jack.state == "sick" then		
		if jack.line>0 and strictcheckhole(jack.line)==1 then 
			jack.anim = 0			
			jack.state = "fall"
		else
			local iskeyb = nil
			if jack.state ~= "sick" then
				for k,v in pairs(keyboard.pressed) do
					if k=="left" then
						jack.x = jack.x - jackspeed
						if jack.x + jack.w < 1 then
							jack.x = WIDTH - halfjack
						end
						-- left
						if jack.state~=k then
							jack.anim = 0
							jack.state = k
						end
						iskeyb = 1
					elseif k=="right" then
						jack.x = jack.x + jackspeed
						if jack.x > WIDTH then
							jack.x = - halfjack
						end
						-- right
						if jack.state~=k then
							jack.anim = 0
							jack.state = k
						end
						iskeyb = 1
					elseif k=="space" then					
						-- jump/space						
						if jack.line<lines and checkhole(jack.line+1) then					
							jack.anim = 0
							jack.state = k
							addhole()
						elseif jack.line==lines then
							jack.anim = 0
							jack.state = k
						else
							jack.anim = 0
							jack.state = "sick"
						end
						keyboard.pressed={}	
						iskeyb = 1
					elseif k=="return" then
						nextlevel()
						keyboard.pressed={}
						iskeyb = 1
					elseif k=="s" or k=="S" then
						soundonoff()
						keyboard.pressed={}
					elseif k=="m" or k=="M" then
						musiconoff()
						keyboard.pressed={}
					end
				end
				if checkCollision() then
					jack.anim = 0
					jack.state = "sick"
				elseif not iskeyb and jack.state ~= "idle" then
					jack.state = "idle"
					jack.anim = 0
				end
			end
		end
	elseif jack.state == "space"  then					
		jack.y = jack.y + jackspeed
		if jack.y>(jack.line+1)*HX then
			jack.state = "idle"
			jack.line = jack.line + 1
			jack.y = jack.line*HX
			jack.anim = 0
			score = score + 5 *level
		end
		if jack.line > lines then
			nextlevel()
		end
		keyboard.pressed={}
	elseif jack.state == "fall"   then	
		jack.y = jack.y - jackspeed
		if jack.y<=(jack.line-1)*HX then
			jack.state = "sick"
			jack.line = jack.line - 1
			jack.y = jack.line*HX
			jack.anim = 0
		end
		keyboard.pressed={}
	elseif jack.state == "sick"   then					
		keyboard.pressed={}
	end
	
	jack.animod = 0 -- idle
	if jack.state == "left" then
		jack.animod = 8
	elseif jack.state == "right" then
		jack.animod = 16
	elseif jack.state == "space" then
		doeffect(jack.state)
		jack.animod = 24
	elseif jack.state == "fall" then
		doeffect(jack.state)
		jack.animod = 32
	elseif jack.state == "sick" then
		doeffect(jack.state)
		jack.animod = 40		
	end
		
	SP_Jack:tile(jack.x, jack.y, jack.anim + jack.animod) 

	-- anim tick
	if timer()-tstart > jsprites.speed[jack.state] then
		if jack.anim < jsprites.tiles-1 then
			jack.anim = jack.anim + 1
		else
			-- anim turn off
			if jack.state == "sick" then
				if jack.line == 0 then lives = lives -1 end
				if lives<1 then
					lives = -1
					level = 0
					nextlevel()
				else
				   jack.state = "idle"
				end
			end
			jack.anim = 0
		end
		tstart = timer()
		effectcleanup()
	end	
end

function movehazards()	
	for k,v in ipairs(enemies) do
		if v.x then
			v.x = v.x + v.dir * jackspeed
			if v.dir>0 and v.x>WIDTH then
				v.x = 1
				v.line = v.line - 1
				if v.line < 1 then
					v.line= lines
				end
			end
			if v.dir<0 and v.x+v.w<1 then
				v.x= WIDTH-v.w
				v.line = v.line + 1 
				if v.line > lines then
					v.line = 1
				end
			end
		end
	end
end

local hstart = timer()

function drawhazard()
	local tick = nil
	if timer()-hstart > esprites.speed then
		tick = 1
		hstart = timer()
	end
	for k,v in ipairs(enemies) do
		local e = v					
		SP_Enemy:tile(e.x, e.line*HX, e.anim + e.animod) 				
		-- anim tick
		if tick then
			if e.anim < esprites.tiles-1 then
				e.anim = e.anim + 1
			else				
				e.anim = 0
			end
		end			
	end	
	movehazards()
end

function isCollision(x1,  y1,  w1,  h1,  x2,  y2,  w2,  h2) 
	return not ((y1+h1 < y2) or (y1 > y2+h2) or (x1 > x2+w2) or (x1+w1 < x2))
end

function checkCollision()
	for k,v in ipairs(enemies) do
		local e = v				
		if isCollision( jack.x, jack.y, jack.w, jack.h, e.x, e.line*HX, e.w, e.h) then
			return 1
		end
	end		
end

function nextlevel()
	jack = { x = (WIDTH-jack.w)/2, y=1, anim=0, line=0 }
	hazards = hazards + 1
	if hazards>0 then
		local ldir = math.random(-1,1)
		if ldir == 0 then ldir = -1 end
		if ldir == 1 then lx = 0 else lx = WIDTH end	
		local ew, eh = SP_Enemy:getTileSize()
		-- local n = math.mod(hazards,esprites.rows)	
		local n = hazards%esprites.rows 
		table.insert(enemies, {dir=ldir, line = 1 + math.random(lines-1), x = lx, anim=0, animod=n*esprites.tiles, w = ew, h=eh} )
	end
	setup()
end

function addhole()
	local dir = math.random(-1,1)
	if dir == 0 then dir = -1 end
	table.insert(holes, {math.random(WIDTH), dir , 1 + math.random(lines-1)} )	
end

function checkhole( line )
	for k,v in ipairs(holes) do
		if line == v[3] then
			if v[1]-jack.w < jack.x and v[1]+holew > jack.x then
				return 1
			end
		end
	end
end

function moveholes()	
	for k,v in ipairs(holes) do
		if v[1] then
			v[1] = v[1] + v[2] * holestep
			if v[2]>0 and v[1]>WIDTH then
				v[1] = 1
				v[3] = v[3] - 1
				if v[3] < 1 then
					v[3] = lines
				end
			end
			if v[2]<0 and v[1]+holew<1 then
				v[1] = WIDTH-holew
				v[3] = v[3] + 1 
				if v[3] > lines then
					v[3] = 1
				end
			end
		end
	end
end

function strictcheckhole( line )
	for k,v in ipairs(holes) do
		if line == v[3] then
			if v[1] < jack.x and v[1] + holew > jack.x+jack.w then
				return 1
			end
		end
	end
end

function drawinfo(j)
	fill(unpack(_GRN))
	text(5,HEIGHT-20, "LEVEL:"..level)
	fill(unpack(_BLU))
	text(WIDTH-85,HEIGHT-20, "LIVES:"..lives)	
	fill(unpack(_MAG))
	local hi = hiscore
	if score > hi then hi = score end
	text(5,5, "SCORE:"..score.."   HISCORE:"..hi)
end

function drawintro()
	background(unpack(_BKG))
	
	if lives<1 then
		-- game ended, hiscoretable
		fill(unpack(_YEL))	
		rect(WIDTH/2-200,HEIGHT/2-40,400,100)
		fill(unpack(_MAG))

		text(WIDTH/2-50,HEIGHT/2+10, "GAME OVER")

		if score > hiscore  then
			fill(unpack(_MAG))
			text(WIDTH/2-70,HEIGHT/2-20, "HIGH SCORE: "..score)
			hiscore = score			
		else
			fill(unpack(_BLU))
			text(WIDTH/2-70,HEIGHT/2-20, "YOUR SCORE: "..score)
		end
	elseif table.getn(balladofjj)>level then
		fill(unpack(_YEL))	
		rect(WIDTH/2-220,HEIGHT/2,440,table.getn(balladofjj[level])*20+10)
		fill(unpack(_BLU))
		for i=1,table.getn(balladofjj[level]) do
			text(WIDTH/2-190,HEIGHT/2+(i-1)*20+5, balladofjj[level][i])
		end
	else
		-- game ended, hiscoretable
		fill(unpack(_YEL))	
		rect(WIDTH/2-220,HEIGHT/2,440,table.getn(balladofjj[level])*20+10)
		fill(unpack(_GRN))
		for i=1,table.getn(balladofjj[level]) do
			text(WIDTH/2-190,HEIGHT/2+(i-1)*20+5, balladofjj[level][i])
		end
		if score > hiscore  then
			fill(unpack(_MAG))
			text(WIDTH/2-70,HEIGHT/2-20, "HIGH SCORE: "..score)
			hiscore = score			
		else
			fill(unpack(_BLU))
			text(WIDTH/2-70,HEIGHT/2-20, "YOUR SCORE: "..score)
		end
	end
end

local musicply = 0

function draw()
	if not intro then
		drawlevel()
		moveholes()	
		drawhazard()			
		musicply = domusic()		
		drawjack()
		drawinfo()				
		if musicply==-1 then
			silence()
		end
	else
		silence()
		drawintro()
		for k,v in pairs(keyboard.pressed) do
			if k then
				intro = nil
				if table.getn(balladofjj)==level or lives<1 then
					level = 0
					score = 0
					hazards = -1
					lives = 1
					enemies = {}
					nextlevel()
				end				
				break
			end
		end
		keyboard.pressed={}
	end
end

