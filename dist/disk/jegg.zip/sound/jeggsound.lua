-----------------------
-- effect demo library -
-----------------------

require "audio"

local game_sound_effects = {}
local effects = {}
local volume = 0.005 -- 1%

-- TONES relative to A4 = 440 Hz
local C4 = 261.63
local G = 400
local C3 = 130.81

local effectch = {}
local sch_count = 1
local loop = 0
local notec = 10
local soundon = true

function effectsetup()			
	effects[1] = sampleBuzz(C4*2, 0.25, 22000)
	effects[2] = sampleBuzz(C3/2, 0.25, 22000)	
	game_sound_effects["space"] = {0,5,10,15,20,25,30,35,40,45}
	game_sound_effects["fall"] = {45,40,35,30,25,20,15,10,5,0}
	game_sound_effects["sick"] = {20,10,0,10,20,30,20,10,0,10}
end

function effectcleanup()
	for i=1,sch_count do
		if effectch[i] then audio.soundStop(effectch[i]) end
	end
end

function soundonoff()
	soundon = not soundon
end

function playEffect(sample, note, volumeL, volumeR, disparity)
	local scale = 2^(note/12)
	local snd = audio.soundLoop(sample, volumeL, volumeR, disparity, scale)
	return snd
end

function doeffect(effect)    	
	loop = loop + 1		
	for i=1,sch_count do
		if effectch[i] then audio.soundStop(effectch[i]) end
		if loop<=notec and soundon then
			local note = game_sound_effects[effect][loop]
			effectch[i] = playEffect(effects[i],note,volume,volume,volume)
		else
			loop = 0
			return -1 -- end off effect
		end			
	end		
end
