-----------------------
-- sound demo library -
-----------------------

NOTES = {}
NOTES["C"]	= 0
NOTES["C#"] = 1
NOTES["D"] 	= 2
NOTES["D#"] = 3
NOTES["E"] 	= 4
NOTES["F"] 	= 5
NOTES["F#"] = 6
NOTES["G"] 	= 7
NOTES["G#"] = 8
NOTES["A"] 	= 9
NOTES["A#"] = 10
NOTES["B"] 	= 11

NOTES["C2"]	= 12
NOTES["C2#"] = 13
NOTES["D2"] = 14
NOTES["D2#"] = 15
NOTES["E2"] = 16
NOTES["F2"] = 17
NOTES["F2#"] = 18
NOTES["G2"] = 19
NOTES["G2#"] = 20
NOTES["A2"] = 21
NOTES["A2#"] = 22
NOTES["B2"] = 23

demosong = {
		{"A", 2, 2},			-- coun
		{"B", 4, 4},			-- try
		{"C2#", 1, 2},			-- roads
		
		{"B", 2, 2},			-- take
		{"A", 4, 4},			-- me 
		{"B", 1, 2},			-- home
		
		{"C2#", 2, 2},			-- to
		{"B", 4, 4},			-- the
		{"A", 1, 2},			-- place
		
		{"C2#", 2, 2},			-- i
		{"E2", 4, 4},			-- be
		{"F2#", 1, 2},			-- long
		
		{"F2#", 2, 2},			-- west
		{"F2#", 4, 4},			-- vir
		{"E2", 1, 2},			-- gin
		{"C2#", 1, 1},			-- ia
		
		{"B", 2, 2},			-- moun
		{"A", 4, 4},			-- tain
		{"B", 1, 2},			-- mom
		{"C2#", 1, 1},			-- ma
		
		{"C2#", 2, 2},			-- take
		{"B", 4, 4},			-- me 
		{"A", 1, 2},			-- home
		
		{"A", 2, 2},			-- coun
		{"B", 4, 4},			-- try
		{"A", 0.5, 0.25},			-- roads
}

local samples = {}
local volume = 0.005 -- 5%

-- TONES relative to A4 = 440 Hz
local C4 = 261.63
local G = 400
local C3 = 130.81

local soundch = {}
local sch_count = 3
local loop = 0
local notec = table.getn(demosong)
local sleep = 0
local pause = 0
local tempo = 250 -- greater value --> slower playbeack
local musicon = true

function musicsetup()
	audio.create()   			
	samples[1] = sampleSine(C4*3, 0.25, 22000)
	samples[2] = sampleBuzz(G, 0.25, 22000)
	samples[3] = sampleBuzz(C3/2, 0.25, 22000)
end

function musiccleanup()
	for i=1,sch_count do
		if soundch[i] then audio.soundStop(soundch[i]) end
	end
	audio.destroy()	
end

function musiconoff()
	musicon = not musicon
end

function playNote(sample, note, volumeL, volumeR, disparity)
	local scale = 2^(note/12)	
	local snd = audio.soundLoop(sample, volumeL, volumeR, disparity, scale)
	return snd
end

function silence()
	for i=1,sch_count do
		if soundch[i] then audio.soundStop(soundch[i]) end
	end
	loop = 0
end

function sampleSine(freq, duration, sampleRate)
	local data = { }
	local sin = math.sin
	local cos = math.cos
	for i = 1,duration*sampleRate do
		data[i] = sin( (i*freq/sampleRate)*math.pi*2)
	end
	return audio.sampleFromMemory(data, sampleRate)
end

function sampleBuzz(freq, duration, sampleRate)
	local om = 0
	local sin = math.sin
	local cos = math.cos
	local data = { }
	for i=1,duration*sampleRate do		
		local val = sin( (i*freq/sampleRate)*math.pi/2) / cos( (i*freq/sampleRate)*math.pi/2)
		table.insert(data,val)
	end
	return audio.sampleFromMemory(data, sampleRate)
end

local mstart = timer()

function domusic()    
	if timer()-mstart > sleep then	
		loop = loop + 1
		if loop>notec then
			return -1 -- End song
		end
		for i=1,sch_count do
			if soundch[i] then audio.soundStop(soundch[i]) end
			-- play note or pause
			local note = NOTES[demosong[loop][1]]
			sleep = tempo / demosong[loop][2]								
			if pause>-1 and musicon then
				soundch[i] = playNote(samples[i],note,volume,volume)					
			end			
		end
		if pause>-1 then
			pause = - tempo / demosong[loop][3]	
			loop = loop - 1 -- play pause next			
		else
			sleep = -1 * pause
			pause = 1
		end
		mstart = timer()
	end	
	return 0
end
