-- videoinit(800,600,0,1)
require "jegg"