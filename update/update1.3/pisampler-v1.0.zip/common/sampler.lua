--------------------------------
-- RPI-64 SMP 
-- Sample Helper 
--------------------------------
-- 
-- shift (+) up to make less silence between peaks
-- shift (-) down to make more silence between peaks
-- 

local smp = {}          

smp.scale = {
{"C", 16.35, 261.63 },
{"C#/Db", 17.32, 277.18},
{"D", 18.35, 293.66 },
{"D#/Eb", 19.45, 311.13 },
{"E", 20.60, 329.63 },
{"F", 21.83, 349.23 },
{"F#/Gb", 23.1, 369.992 },
{"G", 24.50, 392.00 },
{"G#/Ab", 25.96, 415.30 },
{"A", 27.50, 440.00 },
{"A#/Bb", 29.14, 466.16 },
{"B", 30.87, 493.88 },
}

smp.mixer = {}
local sin = math.sin
smp.sampleLen = 0

local PIDEV = 180 / math.pi

local function scut(val,ch)
	local shifth = ch.shfreq
	local shiftv = ch.shamp/100
	local freq = ch.freq
	local amplitude = ch.amp/100
	local hicut = ch.hicut/ 100
	local locut = ch.locut/100
	val = val * amplitude + shiftv
	if val >0 then val = math.min(val,hicut) end
	if val <0 then val = math.max(val,-locut) end	
	return val
end

function smp.init(srate, slen)
	slen = slen or 100
	smp.sampleLen = srate*slen*10
	smp.mixer = {}
	for i=1,smp.sampleLen do	
		smp.mixer[i] = 0
	end
	return smp.mixer
end

function smp.mixerAdd(ch)
	local mode = ch.mix
	local data = ch.data
	local mf
	for i=1,smp.sampleLen do	
		smp.mixer[i] = (smp.mixer[i] or 0)
		data[i] = data[i] or 0
		if mode == 1 then
			smp.mixer[i] = smp.mixer[i] + data[i] 
		elseif mode == 2 then
			smp.mixer[i] = smp.mixer[i] - data[i] 
		end
	end
	return smp.mixer
end

function smp.mixerRemove(ch)
	local mode = ch.mix
	local data = ch.data
	for i=1,smp.sampleLen do	
		smp.mixer[i] = (smp.mixer[i] or 0)
		data[i] = data[i] or 0
		if mode == 1 then
			smp.mixer[i] = smp.mixer[i] - data[i] 
		elseif mode == 2 then
			smp.mixer[i] = smp.mixer[i] + data[i] 				
		end
	end
	return smp.mixer
end
	
function smp.sin( sampleRate, ch )
	local freq = ch.freq	
	local data = ch.data
	local dfi = ch.shfrq/PIDEV
	local d	
	for i=1,smp.sampleLen do
		d = sin((i*freq/sampleRate/1000)*math.pi+dfi)
		data[i] = scut(d,ch)
	end
	return data
end

function smp.sqr( sampleRate, ch )
	local freq = ch.freq
	local amplitude = ch.amp/100
	local data = ch.data
	local dfi = ch.shfrq/PIDEV
	local d
	for i=1,smp.sampleLen do
		d = amplitude 
		if sin(i*freq*math.pi/sampleRate/1000+dfi) < 0 then d = -amplitude end
		data[i] = scut(d,ch) 
	end
	return data
end

function smp.tri( sampleRate, ch )
	local freq = ch.freq
	local data = ch.data
	local dfi = ch.shfrq/PIDEV
	local d
	local m = 1
	for i=1,smp.sampleLen do	
		d = ( math.abs(  i*freq/sampleRate/1000 % ( 2* (m+dfi) ) - (m+dfi)) - (m+dfi)/2 ) * 2
		data[i] = scut(d,ch)
	end
	return data	
end

function smp.saw( sampleRate, ch )
	local freq = ch.freq
	local data = ch.data
	local dfi = ch.shfrq/PIDEV
	local d	
	local m = sampleRate/freq*2*1000
	for i=1,smp.sampleLen do
		d = 2* (i % (m+dfi)) /  (m+dfi)  -1 
		data[i] = scut(d,ch) 
	end
	return data
end

smp.waveForm = {"SIN","TRI","SAW","SQR"}
smp.waveGen =  {smp.sin,smp.tri,smp.saw,smp.sqr}

return smp