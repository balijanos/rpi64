--------------------------------
-- RPI-64 SFONT
-- Sprite Font Library
--------------------------------

local M = {}
          
local FONT_WIDTH=16 	
local FONT_WIDTHB = 2 -- bytes	
local FONT_HEIGHT=16

function M.createFont(bitmapfile, tileW, tileH, shift) 
	local f = {}
	f.sprite = sprite(bitmapfile)
	f.sprite:setTiles(tileW,tileH)		
	f.shift = shift or 0
	-- f.sprite:setColorKey()
	return f
end

function M.text(f,x,y,s,aa,kerning,rotation,zoom,vertical)	
	local w,h = f.sprite:getTileSize()
	kerning = kerning or w
	rotation = rotation or 0
	aa = aa or false	
	zoom = zoom or 1
	if vertical then
		for i=0,string.len(s)-1 do
			f.sprite:tile(x,y+i*kerning,string.byte(s,i+1)-f.shift, rotation, aa, zoom)
		end	
	else 
		for i=0,string.len(s)-1 do
			f.sprite:tile(x+i*kerning,y,string.byte(s,i+1)-f.shift, rotation, aa, zoom)
		end	
	end
end

return M