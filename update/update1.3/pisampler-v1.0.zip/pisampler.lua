--
-- PiSampler V1.0
--
--------------------------------------------------------
require "audio"
spf = require "common.font"
smp = require "common.sampler"
--------------------------------------------------------
dofile("pisampler/samplerdata.lua")
dofile("pisampler/ui.lua")
dofile("pisampler/smanager.lua")
dofile("pisampler/help.lua")
--------------------------------------------------------
local MAXVOL = 100
local done 
local manager
local help
local WGENS = table.getn(waveData)
local actChan = 1
local sound
--------------------------------------------------------
function doTone(n)
	if n and waveData[actChan].on==CHOFF or mainCtrl.on~=1 then return end
	local lpan = MAXVOL/2 - mainCtrl.pan
	local rpan = MAXVOL - lpan	
	if sound then audio.soundStop(sound) sound=nil end	
	if mainCtrl.slen>0 and mainCtrl.srate>0 then
		local sampledata = audio.sampleFromMemory(smp.mixer, mainCtrl.srate*1000)
		if sampledata then		
			sound = audio.soundPlay(sampledata, mainCtrl.vol*lpan/10000, mainCtrl.vol*rpan/10000, 0, mainCtrl.pitch/100)	
			audio.sleep(0.025)
		end
	end
end

function genTone(n)
	n = n or actChan
	local freq = waveData[n].freq
	local amplitude = waveData[n].amp / 100
	local wft = waveData[n].wave
	waveData[n].data = {}
	waveData[n].data = smp.waveGen[wft](mainCtrl.srate, waveData[n] )		
end

function changeTone(n)
	n = n or actChan
	if waveData[n].on==CHON then
		smp.mixerRemove(waveData[n])
	end
	genTone(n)
	if waveData[n].on==CHON then
		smp.mixerAdd(waveData[n])
	end	
	-- doTone(n)	
end

_=[[ -- LOOP ONLY
function updateTones(vol)
	local lpan = vol - mainCtrl.pan
	local rpan = 100 - lpan
	if sound then
		audio.soundUpdate( sound, lpan/100, rpan/100) 
	end
end
]]

function resetBase(n,full)
	if waveData[n].on == CHON and full==nil then
		smp.mixerRemove(waveData[n])
	end
	local base = waveData[n].base
	waveData[n].freq = smp.scale[base][3] * 2 
	waveData[n].step = smp.scale[base][2]
	waveData[n].data = {}
	genTone(n)
	if waveData[n].on == CHON then
		smp.mixerAdd(waveData[n])
	end	
	-- doTone(n)
end

function resetMix(n)
	smp.init(mainCtrl.srate,mainCtrl.slen)
	genTone(n)
	for i=1,WGENS do		
		if waveData[i].on==CHON then
			smp.mixerAdd(waveData[i])
		end	
	end
	-- doTone(n)
end

function resetAll()
	smp.init(mainCtrl.srate,mainCtrl.slen)
	for n=1,WGENS do			
		resetBase(n,true)
	end
	updateUI()
end

function generateAll()
	smp.init(mainCtrl.srate,mainCtrl.slen)
	for i=1,WGENS do		
		genTone(i)
		if waveData[i].on==CHON then
			smp.mixerAdd(waveData[i])
		end	
	end
end

function updateMix(par,n)
	n = n or actChan
	if par=="on" then
		-- test new values
		if waveData[n].on == CHOFF then
			smp.mixerRemove(waveData[n])
		else
			smp.mixerAdd(waveData[n])
		end
		-- doTone(n)
	elseif par=="mix" then
		resetMix(n)
	elseif par=="srate" or par=="slen" then
		generateAll()		
	elseif par=="base" then
		resetBase(n)
	else
		changeTone(n)
	end			
	updateUI()
end

function loadSample(fn)
	local f = io.open(SAMPLEDIR..tostring(fn), "r")
	if f then
		f:close()
		dofile(SAMPLEDIR..fn)
		resetAll()
		return 1
	end
end

function saveSample(fn)
	local out = io.open(SAMPLEDIR..tostring(fn), "wt")
	local line = ""
    for i=1,WGENS do		
		line = "waveData["..i.."]={"..
		"on="..waveData[i].on..",wave="..waveData[i].wave..
		",base="..waveData[i].base..",mix="..waveData[i].mix..
		",amp="..waveData[i].amp..",freq="..waveData[i].freq..
		",step="..waveData[i].step..",shamp="..waveData[i].shamp..",shfrq="..waveData[i].shfrq..
		",hicut="..waveData[i].hicut..",locut="..waveData[i].locut.."}\n"   
		out:write(line)
	end
	line = "mainCtrl={"..
		   "on="..mainCtrl.on..",vol="..mainCtrl.vol..",pan="..mainCtrl.pan..",pitch="..mainCtrl.pitch..
		   ",szoom="..mainCtrl.pitch..",srate="..mainCtrl.srate..",slen="..mainCtrl.slen.."}\n"
	out:write(line)	
    out:close()
end

function kbdEvent()	
	local kbd = nil
	if keyboard.state=="down" then
		kbd = keyboard.key
	end
	return kbd
end

SHIFTINC = nil

function kbdEvent()	
	local kbd = nil
	local kbdu = nil
	if keyboard.state=="down" then
		kbd = keyboard.key
		if kbd == "left shift" then
			SHIFTINC = 1		
		end
	elseif keyboard.state=="up" then
		kbdu = keyboard.key
		if kbdu == "left shift" then
			SHIFTINC = nil		
		end
	end
	return kbd, kbdu
end


function kbdHandler()	
	local kbd = kbdEvent()
	if kbd then
		kbd = string.lower(kbd)
		-- generator select
		if kbd > "0" and kbd < tostring(WGENS+1) then
			actChan = tonumber(kbd) 
			setActChan(actChan)
			updateUI()
		elseif kbd=="f10" then
			keyboard.pressed={}
			manager = true
		elseif kbd=="escape" then
			keyboard.pressed={}
			if help then
				help = nil
			else
				help = true
			end
		elseif kbd > "f0" and kbd < "f"..tostring(WGENS+1) then
			local idx = tonumber(string.sub(kbd,2))
			-- avoid f11 f12 bug
			if idx<WGENS+1 then
				if waveData[idx].on == CHOFF then
					waveData[idx].on = CHON
				else
					waveData[idx].on = CHOFF
				end
				updateMix("on",idx)
			end
		-- waveform control switches
		elseif kbd == "o" then
			setUIControl("on")
		elseif kbd == "w" then
			setUIControl("wave")
		elseif kbd == "x" then
			setUIControl("mix")
		elseif kbd == "b" then
			setUIControl("base")
		-- waveform control pots
		elseif kbd == "a" then
			setUIControl("amp")
		elseif kbd == "f" then
			setUIControl("freq")
		elseif kbd == "s" then
			setUIControl("shamp")	
		elseif kbd == "d" then
			setUIControl("shfrq")	
		elseif kbd == "h" then
			setUIControl("hicut")
		elseif kbd == "l" then
			setUIControl("locut")
		-- mixer control pots	
		elseif kbd == "r" then
			setUIControl("srate")
		elseif kbd == "t" then
			setUIControl("slen")
		elseif kbd == "y" or kbd=="z" then
			setUIControl("szoom")
		elseif kbd == "p" then
			setUIControl("pan")
		elseif kbd == "i" then
			setUIControl("pitch")
		elseif kbd == "v" then
			setUIControl("vol")	
		elseif kbd == "m" then
			mainCtrl.on = -mainCtrl.on
			if mainCtrl.on~=1 then
				if sound then audio.soundStop(sound) end			
			end	
		elseif kbd == "space" then
			doTone()	
		-- cursor keys	
		elseif kbd=="up" then
			adjustParam(nil,1)		
			updateMix(actChan)
		elseif kbd=="down" then
			adjustParam(nil,-1)	
			updateMix(actChan)
		elseif kbd=="right" then
			adjustParam(nil,1)	
			updateMix(actChan)			
		elseif kbd=="left" then
			adjustParam(nil,-1)	
			updateMix(actChan)
		-- quit	
		elseif kbd=="q" then
			done = true
		end
	end
end

function mouseHandler()
	if mouse.pressed['1'] then
		-- close help
		if help then
			help = nil
			return
		end
		-- chn select
		local n = findGenXY(mouse.x,mouse.y)
		if n then
			actChan = n
			setActChan(n)
			updateUI()
			return
		end
		local c,i = findSwitchXY(mouse.x,mouse.y)
		if c then
			local n,o = adjustParam(c,i)
			if n~=o then
				updateMix(c)
				-- updateUI(c)
			end
			return
		end		
		c,i = findKnobXY(mouse.x,mouse.y)
		if c then
			local n,o = adjustParam(c,i)
			if n~=o then
				updateMix(c)
				-- updateUI(c)
			end
			return 
		end		
	end
end

--------------------------------------------------------
local tstart = timer()
local elapsed
function draw()
	background(0,0,0,0)
	elapsed = timer()-tstart
	if help then
		showHelp(WIDTH/2-180,HEIGHT-50)	
	else
		drawUI()
		if elapsed<4000 then
			showHint()
		end
	end
	if manager then
		local ret = sman_draw()
		if ret==1 then manager=nil end
	else		
		-- local elapsed = timer()-tstart			
		kbdHandler()
		mouseHandler()		
		if done then return 1 end
	end
end
--------------------------------------------------------
function setup()  	
	audio.create() 	
	if arg==nil or loadSample(arg[2]) == nil then
		resetAll()
	end	
	setActChan(actChan)
	updateUI()
	draw()
end
--------------------------------------------------------
function cleanup()
	audio.destroy()	
	saveSample(SAMPLEWRK)	
	waveData = {}
	mainCtrl = {}
	smp.mixer = {}
	collectgarbage()
end
