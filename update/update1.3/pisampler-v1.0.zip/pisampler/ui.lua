--
-- PiSampler UI
--
--
BCOLOR = {0x40,0x40,0x40,0x80}

sFont = spf.createFont( "gfx/smallfont.png", 16, 16, 0)
sFont_b = spf.createFont( "gfx/smallfont_black.png", 16, 16, 0)
sFont_d = spf.createFont( "gfx/smallfont_dark.png", 16, 16, 0)	
sFont_sb = spf.createFont( "gfx/smallfont_8x8_black.png", 16, 16, 0)	
sFont_sh = spf.createFont( "gfx/smallfont_8x8.png", 16, 16, 0)	
sFont_sd = spf.createFont( "gfx/smallfont_8x8_dark.png", 16, 16, 0)	

local knob = sprite("gfx/knob_small_0.png") 
local knob_s = sprite("gfx/knob_sw_small_0.png") 
local scalept = sprite( "gfx/scalep.png")	

rpilogo = sprite( "gfx/rpi.png")	
textlogo = sprite( "gfx/logo.png")	

local knobSize = 60
local knobSize_s = 40

local POTMAX = 300
local PIDEV = 180 / math.pi

local cx = (WIDTH)/2
local cy = (HEIGHT)/2

local actChan = 1
local actCtrl = "vol"

local mixWidth = 350

function getChanData(n)
	n=n or actChan
	return waveData[n]
end

function getMainCtrl()
	return mainCtrl
end

function getOnOff()
	return {"OFF","ON"}
end

function getWaveForm()
	return smp.waveForm
end

function getMixMode()
	return {"ADD","SUB"}
end

function getBaseScale()
	return {"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"}
end

function setActChan(n)
	actChan = n
end

function getFreqMax()
	return waveData[actChan].step * POTMAX
end

function getFreqInc()
	return waveData[actChan].step/2
end

function getSampleLen()
	return smp.sampleLen
end

function getMaxSamplerate()
	return MAXSAMPLERATE
end

function getMinSampleLen()
	return math.floor(mixWidth/mainCtrl.srate/1000)
end

function getFileMode()
	return {"LOAD","LIVE","SAVE"}
end

local knobs = { -- position from center	
	-- SWITCHES
	{x=-120, y=40,  level=-40,   size=knobSize_s, info="on",     label="ON/OFF", switch=2,   data=getOnOff},
	{x=-330, y=40,  level=-80,   size=knobSize_s, info="wave",   label="WAVE",   switch=4,   data=getWaveForm},  
	{x=-270, y=40,  level=-40,   size=knobSize_s, info="mix",    label="MIX",    switch=2,   data=getMixMode},  
	{x=-210, y=40,  level=-140,  size=knobSize_s, info="base",   label="BASE",   switch=12,  data=getBaseScale},  
	
		
	-- CHANNEL POTS
	{x=-180, y=-190, level=0,    size=knobSize,   info="amp",    label="AMP"}, 	-- amplitude
	{x=-330, y=-190, level=0,    size=knobSize,   info="freq",   label="FREQ"},	-- frequency
		
	{x=-110, y=-190, level=0,    size=knobSize_s,   info="shamp",  label="AMP"..string.char(0x86)}, 
	{x=-260, y=-190, level=0,    size=knobSize_s,   info="shfrq",  label="FREQ"..string.char(0x86)}, 
	
	{x=-40,  y=-30,  level=0,    size=knobSize_s, info="hicut",  label="HiCUT"}, 		
	{x=-40,  y=-110, level=0,    size=knobSize_s, info="locut",  label="LoCUT"}, 	
	
	-- MAIN CONTORLS 
	{x=40,   y=40,   level=0,    size=knobSize_s, info="srate",  label="SAMPLERATE",    },	-- SAMPLERATE
	{x=270,  y=40,   level=0,    size=knobSize_s, info="slen",	 label="LEN",    }, 	-- SAMPLE LENGTH

	{x=330,  y=40,   level=0,    size=knobSize_s, info="szoom",  label="ZOOM",   },	 

	{x=185,  y=-190, level=0,    size=knobSize_s, info="pan",    label="PAN",    },	-- PAN
	{x=40,   y=-190, level=0,    size=knobSize, info="pitch",	 label="PITCH",  }, 	-- PITCH
	{x=330,  y=-190, level=0,    size=knobSize,   info="vol",    label="VOL",    }, 	-- MAIN VOLUME

 }
 
 local KNOBS = table.getn(knobs)
 
 local knobProps = {	
	on =   { max = 2,           min = 1, inc=1,         dfi = -40,   knob = 1 },
	wave = { max = 4,           min = 1, inc=1,         dfi = -80,   knob = 2 },
	mix =  { max = 2,           min = 1, inc=1,         dfi = -40,   knob = 3 },
	base = { max = 12,          min = 1, inc=1,         dfi = -140,  knob = 4 },
	
	amp =   { max = 400,        min = 0, inc=5,          dfi = -150,  knob = 5 },
	freq =  { max = getFreqMax, min = 0, inc=getFreqInc, dfi = -150,  knob = 6 },
	shamp = { max = 400,        min = -400, inc=5,       dfi = 0,     knob = 7 },
	shfrq = { max = 90,         min = -90, inc=5,         dfi = 0,     knob = 8 },
	
	hicut = { max = 400,        min = 0, inc=5,          dfi = -150,  knob = 9 },
	locut = { max = 400,        min = 0, inc=5,          dfi = -150,  knob = 10},
	
	srate = { max = getMaxSamplerate,min =2.75625, inc=2.75625, 
			  dfi = -165,  knob = 11, link=getMainCtrl },
	slen =  { max = 100,        min = 0, inc = 5,           
			  dfi = -150,  knob = 12, link=getMainCtrl },
	
	szoom = { max = 100,        min =0,  inc=5,           dfi = -150,  knob = 13, link=getMainCtrl },	
	
	pan =   { max = 50,         min = -50, inc=5,         dfi = 0,     knob = 14, link=getMainCtrl },
	pitch = { max = 200,        min = 0, inc=5,           dfi = -150,  knob = 15, link=getMainCtrl },
	vol   = { max = 100,        min = 0, inc=5,           dfi = -150,  knob = 16, link=getMainCtrl },
	
}

 local waveGenPos = { -- position from center	
	{x=-300,y=80},  {x=-180,y=80},  {x=-60,y=80},  {x=60,y=80}, {x=180,y=80}, {x=300,y=80},
 }
local WGENS = table.getn(waveGenPos)
local tick = {}
local tstart = timer()

function drawScale(cx,cy,r,s)	-- center, radius, space
	local x,y = cx,cy
	local lx,ly = x,y
	fill(0xFF,0xFF,0x80,0x80)
	y = cy + r
	for i=-10,10 do			
		lx,ly = rotate(x,y,cx,cy,(i*15)/PIDEV)
		-- line(lx,ly,cx,cy)
		scalept:draw(lx-1,ly-1,1)
	end	
	s = s or 2
	filled(true)
	fill(unpack(BCOLOR))
	ellipse(cx,cy,r-s,r-s)
end

function calcDFi(n)
	-- return (24-n) + (n-12) * 6
	return 5*n - 48
end

function drawScaleSw(n,cx,cy,r,s)	-- center, radius, space
	s = s or 2
	local x,y = cx,cy
	local lx,ly = x,y
	fill(0xFF,0xFF,0x80,0x80)
	y = cy + r
	for i=-n+1,n-1 do	
		if i % 2 == 1 then
			lx,ly = rotate(x,y,cx,cy,-(i*calcDFi(n))/PIDEV)
			-- line(lx,ly,cx,cy)
			scalept:draw(lx-1,ly-1,1)
		end
	end
	s = s or 2
	filled(true)
	fill(unpack(BCOLOR))
	ellipse(cx,cy,r-s,r-s)
end

function drawLabel(font,cx,cy,str,kern,boxed)
	str = str or ""
	local dx = (string.len(str)*(kern or 8))/2
	filled(true)
	if boxed then 
		fill(0x60,0x60,0x60,0xFF)
		rect(cx-dx-2,cy,2*dx+5,11)
	end
	-- fill(0x20,0x80,0x20,0x40)			
	spf.text(font,cx-dx,cy,str,true,(kern or 8))
end


function drawKnob(n,val)	-- center, radius, len, space
	local x = cx+knobs[n].x
	local y = cy+knobs[n].y
	local lPos = -16
	local hSize = knobs[n].size/2
	
	if knobs[n].size==knobSize_s then
		if knobs[n].switch then				
			drawScaleSw(knobs[n].switch,x,y,knobSize_s/2+4)
		else
			drawScale(x,y,knobSize_s/2+4)					
		end		
		knob_s:draw(x-hSize,y-hSize,-knobs[n].level,true)
	else
		drawScale(x,y,knobSize/2+4)
		knob:draw(x-hSize,y-hSize,-knobs[n].level,true)
	end
	
	if knobs[n].info==actCtrl then
		drawLabel(sFont_sh,x,y-hSize+lPos,knobs[n].label,6)
	else	
		drawLabel(sFont_sd,x,y-hSize+lPos,knobs[n].label,6)
	end
				
	if val then
		drawLabel(sFont_sh,x,y-5,val,6,true)
	else
		local d = getPropValue(knobs[n].info,"link")
		if d ==nil then
			d = getChanData()
		end
		
		if knobs[n].switch and knobs[n].data then
			--  propTable[waveData[actChan].option.value]
			--  propTable[mainCtrl.option.value]
			val = knobs[n].data()[d[knobs[n].info]]		
		else	
			-- dataTable[option]
			val = d[knobs[n].info]
		end			
					
		if type(val)=="number" then
			drawLabel(sFont_sh,x,y-5,string.format("%d",val),6,true)
		else
			drawLabel(sFont_sh,x,y-5,val,6,true)
		end
	end
end


function drawSample(x,y,n,len,mul,opt)
	local d = waveData[n].data
	if not d then return end	
	fill(0x80,0x80,0xD0,0x80)
	line(x,y,x+len,y)
	
	if opt then
		-- CUT
		fill(0xC0,0x50,0x50,0x20)
		local hcy = y+waveData[n].hicut/100*mul
		line(x,hcy,x+len,hcy)
		local lcy = y-waveData[n].locut/100*mul
		line(x,lcy,x+len,lcy)
	end
	
	if actChan==n then
		fill(0xB0,0xE0,0xB0,0xD0)
	else
		fill(0x20,0xD0,0x20,0xF0)
	end
	for i=1,len do
		if d[i*2] then
			putpixel(x+i,y+d[i*2]*mul)
		end
	end
end

function drawGen(n)
	
	if n==actChan then
		fill(0x20,0xD0,0x20,0xF0)
	else
		fill(0x10,0x40,0x10,0x40)
	end
	
	filled(false)
	rect(cx+waveGenPos[n].x-knobSize,cy+waveGenPos[n].y-3,2*knobSize-2,150)
	filled(true)
	
	local x = cx+waveGenPos[n].x - 55
	local f = sFont_sh
	if waveData[n].on == CHOFF then
		f = sFont_sd
	end
	spf.text(sFont_sh,x,cy+waveGenPos[n].y+130,"GEN-"..n,true,7)
	spf.text(f,x+44,cy+waveGenPos[n].y+130,smp.waveForm[waveData[n].wave],true,7)
	
				
	drawSample(x,cy+waveGenPos[n].y+80,n,110,10)
	spf.text(f,x,cy+waveGenPos[n].y+24, "Base =  "..smp.scale[waveData[n].base][1],true,7)	
	spf.text(f,x,cy+waveGenPos[n].y+12, "Freq =  "..string.format("%.2f",waveData[n].freq),true,7)	
	spf.text(f,x,cy+waveGenPos[n].y,	"Ampl =  "..string.format("%d",waveData[n].amp).." %",true,7)
	
	-- else
	if actChan==n then
		drawSample(cx-360,cy-70,n,270,15,true)	
	end	
	
end

function drawOut()	
	fill(0x20,0x40,0x20,0x40)
	filled(false)
	-- mix
 	rect(cx+10,cy-140,350,140)
	-- active sample
	rect(cx-360,cy-140,270,140)
	filled(true)
			
	if mainCtrl.on == -1 then
		drawKnob(knobProps["vol"].knob,"MUTE")
	end
end

function drawMix()
	local d = smp.mixer
	if not d then return end
	fill(0x80,0x80,0xD0,0x80)
	line(cx+20,cy-70,cx+mixWidth,cy-70)
	fill(0x20,0xE0,0x60,0xE0)	
	local z = mainCtrl.szoom
	local ds = math.floor(smp.sampleLen/mixWidth)
	if ds<1 then ds=1 end	
	if z<1 then z=1 end		
	ds = math.ceil(ds/z)	
	-- print(z,ds,350*ds,smp.sampleLen)	
	for i=0,mixWidth-1 do
		if d[1+i*ds] then
			putpixel(cx+10+i,cy-70+d[1+i*ds]*10)
		end
	end
end

function findGenXY(x,y)
	for n=1,WGENS do
		if x > cx+waveGenPos[n].x-60 and x < cx+waveGenPos[n].x+knobSize and
		   y > cy+waveGenPos[n].y-3  and y < cy+waveGenPos[n].y-3+150 then			
			return n
		end
	end	
end

function findSwitchXY(x,y)
	for n=1,KNOBS do
		if knobs[n].switch then
			if x > cx + knobs[n].x - knobSize_s/2 and x < cx + knobs[n].x + knobSize_s/2 and
			   y > cy + knobs[n].y - knobSize_s/2 and y < cy + knobs[n].y + knobSize_s/2 then
			   if y > cy + knobs[n].y then
					  return knobs[n].info,1
				else
					  return knobs[n].info,-1
				end	
			end
		end
	end	
end

function findKnobXY(x,y)
	for n=1,KNOBS do
		if knobs[n].switch==nil then
			if x > cx + knobs[n].x - knobSize/2 and x < cx + knobs[n].x + knobSize/2 and
			   y > cy + knobs[n].y - knobSize/2 and y < cy + knobs[n].y + knobSize/2 then				   
				if y > cy + knobs[n].y then
					  return knobs[n].info,1
				else
					  return knobs[n].info,-1
				end	
			end
		end
	end	
end

function drawKnobs()
	for i=1,KNOBS do
		drawKnob(i)
	end
end

function getPropValue(k,p)
	if type(knobProps[k][p]) == "function" then
		return knobProps[k][p]()
	else
		return knobProps[k][p]
	end
end

function knobLevel(n,val)	
	-- switch
	local par = knobs[n].info	
	local d = getPropValue(par,"link")
	if d == nil then
		d = getChanData()
	end
	if knobs[n].switch then				
		local dfi = calcDFi(knobs[n].switch)
		if dfi>0 then dfi=-dfi end
		val = d[par]
		local p = knobs[n].switch * dfi - dfi
		knobs[n].level = p - (val-1) * dfi * 2
	-- pots
	else					
		local max = getPropValue(par,"max")
		local min = getPropValue(par,"min")
		local dfi = getPropValue(par,"dfi")
		knobs[n].level = val or dfi + d[par]*POTMAX/(max-min)		
	end
end

function adjustParam(par,up)	
	par = par or actCtrl
	local d = getPropValue(par,"link")
	if d ==nil then
		d = getChanData()
	end

	local max = getPropValue(par,"max")
	local min = getPropValue(par,"min")
	local inc = SHIFTINC or getPropValue(par,"inc")			
	
	local oldV = d[par]
	
	if (up>0 and d[par]<max) or (up<0 and d[par]>min) then		
		d[par] = d[par]+inc*up		
	end
	if up>0 then
		d[par] = math.min(max,d[par])
	else
		d[par] = math.max(min,d[par])
	end	
	knobLevel(knobProps[par].knob)
	return d[par],oldV
end

function setUIControl(ac)
	actCtrl = ac
end

function drawUI()	
	for i=1,WGENS do
		 drawGen(i)
	end	
	drawKnobs()
	drawOut()
	drawMix()
	rpilogo:draw(WIDTH/2-55,HEIGHT/2+20)
	textlogo:draw(WIDTH/2+110,HEIGHT/2+10)
end

function updateUI(par)	
	if par then
		local n = getPropValue(par,"knob")
		knobLevel(n)
	else
		for i=1,KNOBS do
			knobLevel(i)
		end
	end
end