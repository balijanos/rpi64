--
-- PiSampler Help
--

function showHint()
spf.text(sFont,WIDTH/2+100,HEIGHT/2-40,"PRESS ESC TO HELP",true,9)
end

function showHelp(x,y)
background(0x80,0xB0,0xB0,0x90)
local inc = 12
spf.text(sFont_d,x-20,y+inc*2,"GLOBAL KEYBOARD COMMANDS",true,9)
spf.text(sFont_b,x,y+inc*1,"ESC       help (this screen)",true,9)
spf.text(sFont_b,x,y-inc*0,"1  - 6    select generator channel",true,9)
spf.text(sFont_b,x,y-inc*1,"F1 - F6   turn channel on/off",true,9)
spf.text(sFont_b,x,y-inc*2,"M         mute output",true,9)
spf.text(sFont_b,x,y-inc*3,"SPACE     play sample",true,9)
spf.text(sFont_b,x,y-inc*4,"Q         quit",true,9)
spf.text(sFont_b,x,y-inc*5,"F10       sample manager (load,save etc.)",true,9)

spf.text(sFont_d,x-20,y-inc*7,"SELECT WAVE GENERATOR CONTROL",true,9)
spf.text(sFont_b,x-10,y-inc*8,"switches",true,9)
spf.text(sFont_b,x,y-inc*9,"O    on/off",true,9)
spf.text(sFont_b,x,y-inc*10,"W    waveform",true,9)
spf.text(sFont_b,x,y-inc*11,"B    base frequency (scale)",true,9)
spf.text(sFont_b,x,y-inc*12,"X    mix mode",true,9)

spf.text(sFont_b,x-10,y-inc*14,"potmeters",true,9)
spf.text(sFont_b,x,y-inc*15,"A    amplitude",true,9)
spf.text(sFont_b,x,y-inc*16,"F    frequency",true,9)
spf.text(sFont_b,x,y-inc*17,"S    amplitude shift",true,9)
spf.text(sFont_b,x,y-inc*18,"H    hi-cut",true,9)
spf.text(sFont_b,x,y-inc*19,"L    lo-cut",true,9)
 
spf.text(sFont_d,x-20,y-inc*21,"OUTPUT CONTROLS",true,9)
spf.text(sFont_b,x,y-inc*22,"V    volume",true,9)
spf.text(sFont_b,x,y-inc*23,"I    pitch",true,9)
spf.text(sFont_b,x,y-inc*24,"P    pan",true,9)
spf.text(sFont_b,x,y-inc*25,"T    samplerate",true,9)
spf.text(sFont_b,x,y-inc*26,"T    sample length",true,9)
spf.text(sFont_b,x,y-inc*27,"Z    output wave zoom",true,9)

spf.text(sFont_b,x-20,y-inc*29,"UP/DOWN or LEFT/RIGHT    adjust selected control",true,9)

spf.text(sFont_d,WIDTH/2-100,y-inc*33,"PRESS ESC TO CONTINUE",true,9)

textlogo:draw(10,HEIGHT-50)
end