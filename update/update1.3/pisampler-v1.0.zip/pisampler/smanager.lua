--
-- PiSampler Sample Manager
--
-- modified shell/fman
--
spf = require "common.font"
local sFont_sb = spf.createFont( "gfx/smallfont_black.png", 16, 16, 0)	
local sFont_sh = spf.createFont( "gfx/smallfont.png", 16, 16, 0)	
local sFont_sd = spf.createFont( "gfx/smallfont_dark.png", 16, 16, 0)	

local hb = 10
local hfw = WIDTH/2-15
local hfh = HEIGHT/2
local fk = 9

local root = SAMPLEDIR

lfs.mkdir(_SAVES_ROOT)
lfs.mkdir(SAMPLEDIR)

local popup = nil
local cbfunc = nil -- callback if any
local cbparms = {} -- callback parameters

local pane = {
	path = {root},
	files = nil,
	sel = 0,
	min = 0,
	max = 0,
}


local act = 0
local size = nil

local function frame(whole)
	if whole==nil then
		filled(true)
		fill(0x40,0x40,0x40,0x80)
		rect(hb,hb,hfw,hfh)
	else
		filled(false)
		fill(0x20,0x80,0x20,0x40)		
		rect(hb,hb,hfw,hfh)
		line(hb,hfh-hb,hfw+hb,hfh-hb)
		line(hb,3*hb,hfw+hb,3*hb)
		local str  = "F2       F3       F6         F8         F10"
		local str2 = "   SAVE     LOAD     RENAME     DELETE      QUIT"
		local dx = (WIDTH-12*string.len(str))/2
		spf.text(sFont_sh,2*hb,hfh-hb+2,str,true,fk-1.5)
		spf.text(sFont_sd,2*hb,hfh-hb+2,str2,true,fk-1.5)
	end
end

local inputString = ""

function draw_input_xy(x,y) 	
	local n = popup.len or 32
	spf.text(sFont_sh,x,y, inputString .. "_",true,fk-1)
	for k,v in pairs(keyboard.pressed) do
		if k and string.len(k)==1 and string.len(inputString)<n then
			inputString = inputString .. tostring(k)
		else
			if k and k=="backspace" then
				inputString = string.sub(inputString,1,-2)
			elseif k and k=="return" then
				return 1
			elseif k and k=="escape" then
				inputString = ""
				return 1
			end
		end
    end
	keyboard.pressed={} -- reset
	return 0
end

local function doInput()		
	spf.text(sFont_sd,2*hb,hb+2,popup.message,true,fk-1.5)
	if  draw_input_xy(2*hb+string.len(popup.message)*(fk-1.5)+2,hb+2)==1 then
		popup=nil
	end
end

local function doCallback()
	if type(cbfunc)=="function" and type(cbparms)=="table" then
		local f = cbfunc
		local t = cbparms
		cbfunc = nil
		cbparms = {}
		f(unpack(t))		
	end
end

local function doPopup()
	if popup.input then
		return doInput()
	end
		
	spf.text(sFont_sd,2*hb,hb+2,popup.message,true,fk-1.5)
	
	if popup.buttons then
		for k,v in ipairs(popup.buttons) do
			if keyboard.pressed[v] then				
				if popup.funcs and popup.funcs[k] then
					-- popup = {message = "CALL", header="CALL"}					
					if popup.args and popup.args[k] then
						popup.funcs[k](unpack(popup.args[k]))
					else					
						popup.funcs[k]()
					end					
				end
				popup = nil
			end
		end
	end
	if keyboard.pressed['escape'] or keyboard.pressed['return'] then
		popup = nil
	end
end

local function showFiles(pane,paneid)	
	local y = hfh-3*hb
	local x = 2*hb + paneid*(hfw+hb)
	local str = nil
	if pane.sel<1 then pane.sel = 1 end
	if pane.sel>pane.max then pane.sel = pane.max end
	for k,v in pairs(pane.files) do
		if k>=pane.min and y>3*hb then
			str = v.name
			if paneid==act and pane.sel == k then
				filled(true)
				fill(0x20,0x80,0x20,0x40)
				rect(x-2,y-2,WIDTH/2-3*hb,12)
			end
			spf.text(sFont_sh,x,y-3,str,true,fk)
			y = y - 14
		else
			size = size or k
		end
	end
end

local function _sort_files(a,b)
  return a.name < b.name
end

local function getFiles(path,noup)
	local files = {}
	local oldpath=lfs.currentdir()
	lfs.chdir(root)		
	for file in lfs.dir(".") do
		local attr = lfs.attributes (file)
		if attr.mode ~= "directory" then			
			if type(attr)=="table" then				
				table.insert(files, {name=file,attr=attr})
			end
		end
	end	
	table.sort(files,_sort_files)
	lfs.chdir(oldpath)	
	return files
end

local function findPanePos(pane,elem)
	for k,v in pairs(pane.files) do
		if v.name ~= elem then
			local s = size or 999
			if pane.sel+pane.min>=s and pane.sel<pane.max then pane.min = pane.min + 1 end
			pane.sel = pane.sel + 1	
		else
			break
		end
	end
end

local function findPaneFile(pane,elem)
	for k,v in pairs(pane.files) do
		if v.name == elem then
			return 1
		end
	end
end

local function refreshPane(pane, full)	
	local noup = (table.concat(pane.path)==root)
	pane.files = getFiles(table.concat(pane.path,"/"),noup)
	if full then	
		pane.min = 1
		pane.sel = 1
	end
	pane.max = table.getn(pane.files)
end

local function refreshPanes(full)
	refreshPane(pane, full)
end

---------------------------------------
local function deleteFile(pane)
	local fn = "/"..pane.files[pane.sel].name
	INTP_delete(table.concat(pane.path,"/")..fn)
	if pane.sel == pane.max then pane.sel=pane.sel-1 end
	refreshPanes()
end

local function copyFile(tname)
	if pane.files[pane.sel].attr ~= "directory" then
		local source = nil
		local target = nil
		local fn = "/"..pane.files[pane.sel].name				
		source = table.concat(pane.path,"/")..fn
		local fn = "/"..tname
		target = table.concat(pane.path,"/")..fn
		if source==target then		
			popup = {message = "Can't copy file to itself!", error=true}
		elseif source and target and source~=target and INTP_filecopy(source,target)==nil then			
			popup = {message = "File write error!", error=true}
		else	
			-- refresh target pane			
			refreshPane(pane)		
			return true
		end			
	end
end

local function renameFile()
	local fn = "/"..pane.files[pane.sel].name
	if pane.files[pane.sel].name==inputString then
		popup = {message="Can't move file to itself!", header="Error",error=true}
	elseif INTP_filecopy(table.concat(pane.path,"/")..fn,table.concat(pane.path,"/").."/"..inputString) then
		deleteFile(pane)
	else	
		popup = {message="Can't rename file!", header="Error",error=true}
	end		
end

local function saveFile()
	local fn = inputString
	saveSample(fn)
	refreshPanes()
end
---------------------------------------

local function kbdHandler()	
	if popup then
		doPopup()
	elseif cbfunc then
		doCallback()
    elseif keyboard.pressed['up'] then
		local s = size or 999
		if pane.min>=pane.sel and pane.sel>1 then pane.min = pane.min - 1 end
		pane.sel = pane.sel - 1	
    elseif keyboard.pressed['down'] then	
		local s = size or 999
		if pane.sel+pane.min>=s and pane.sel<pane.max then pane.min = pane.min + 1 end
		pane.sel = pane.sel + 1		
	elseif keyboard.pressed['f2'] then
		popup = {message="Save file as:", input=true }	
		cbfunc = saveFile 
		cbparms = {}
	elseif keyboard.pressed['f3'] or keyboard.pressed['return'] then
		local f = pane.files[pane.sel]
		if f and f.attr.mode~="directory" then
			loadSample(f.name)
			return 1
		end
	elseif keyboard.pressed['f6'] then		
		inputString = pane.files[pane.sel].name
		popup = {message="Rename to:", input=true }	
		cbfunc = renameFile 
		cbparms = {}		
	elseif keyboard.pressed['f8'] then
		popup = {message="Do you want delete the file? (Y/N)", buttons={"y","n"},funcs={deleteFile},args={ {pane} }}
	elseif keyboard.pressed['escape'] or keyboard.pressed['f10'] then
		keyboard.pressed={}
		return 1
	end
	keyboard.pressed={}
end
 
function sman_draw()	
    frame()
	if pane.files==nil then
		refreshPanes(true)
	end
	showFiles(pane,0)
	frame(1)
	return kbdHandler()
end

-- draw = sman_draw