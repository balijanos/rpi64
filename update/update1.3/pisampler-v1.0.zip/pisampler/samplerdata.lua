--
-- PiSampler Data Ddefinition
--
--
-- CONST
CHOFF = 1
CHON = 2
_SAVES_ROOT = _UPDATE_ROOT.."saves/"
SAMPLEDIR = _SAVES_ROOT.."/pisampler/"
SAMPLEWRK = "work.smp"
MAXSAMPLERATE = 44.1 -- KHZ
local SAMPLERATE = 22.050 -- KHZ
-- DATA structures
waveData = {
	{on =  CHOFF, wave=1, base=1, mix=1, amp=100, freq=0, step=0, shamp=0, shfrq=0, hicut=200, locut=200}, 
	{on =  CHOFF, wave=2, base=1, mix=1, amp=100, freq=0, step=0, shamp=0, shfrq=0, hicut=200, locut=200}, 
	{on =  CHOFF, wave=3, base=1, mix=1, amp=100, freq=0, step=0, shamp=0, shfrq=0, hicut=200, locut=200}, 
	{on =  CHOFF, wave=4, base=1, mix=1, amp=100, freq=0, step=0, shamp=0, shfrq=0, hicut=200, locut=200},
	{on =  CHOFF, wave=1, base=1, mix=1, amp=100, freq=0, step=0, shamp=0, shfrq=0, hicut=200, locut=200}, 
	{on =  CHOFF, wave=1, base=1, mix=1, amp=100, freq=0, step=0, shamp=0, shfrq=0, hicut=200, locut=200},
 } 

mainCtrl = {
	on = 1, type="OUT", vol=50, pan=0, pitch=100, srate=SAMPLERATE, slen = 100, sshift=0, szoom=100,
 }
