local sstart = nil

function setup()
    print("SETUP...")
	print("Press SHIFT+ESC to abort program")
end

function draw()    
	local elapsed = timer() - (sstart or timer())	
	if sstart==nil or  elapsed > 990 then
		sstart = timer()	
		print("Elapsed time: " .. elapsed)        	
    end
end

function cleanup()
    print("CLEANUP")
end
