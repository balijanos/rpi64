--
-- run args.lua 1 Param2 3.14 "hello world"
-- 
for k,v in pairs(arg) do
	print(k,v)
end