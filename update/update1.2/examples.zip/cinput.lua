function draw()
    print("INPUT:")
    local a = input()
    print("Input was:",a)
    return 1
end
