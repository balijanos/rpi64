function f1()
	print(1)
-- continue	
	return 0
end

function f2()
	print(2)
-- continue	
	return 0
end

function f3()
	print(3)
-- finish	
	return 1
end

function f4()
	-- never called
	print(4)
	return 0
end
----------------------------------------
local loop = 0

function setup()
	print("setup called")
end

function draw()
	loop = loop + 1
	if loop ==  1 then
		return f1()
	elseif loop == 2 then
		return f2()
	elseif loop == 3 then
		return f3()
	else
		return f4()
	end
end

function cleanup()
	print("cleanup called")
end
