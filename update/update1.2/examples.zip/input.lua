local x,y = WIDTH/2-80, HEIGHT/2
local inpstr = ""
local inplength = 11

function setup()
	fill(128,128,200,100) 
	text(x,y, "ENTER YOUR NAME:")
 keyboard.pressed={} -- reset
end

function draw_input_xy(x,y) 
	
	local n = inplength
	fill(0, 0, 0, 1)
	rect(x, y, (n+1)*10,20)
 fill(100,100,100,255)
	text(x,y, inpstr .. "_")
	for k,v in pairs(keyboard.pressed) do
		if k and string.len(k)==1 and string.len(inpstr)<n then
			inpstr = inpstr .. string.upper(tostring(k))
		else
			if k and k=="backspace" then
				inpstr = string.sub(inpstr,1,-2)
			elseif k and k=="return" then
				return 1
			end
		end
    end
 keyboard.pressed={} -- reset
	return 0
end

function draw()
	return draw_input_xy(x+20,y-20)
end

function cleanup()
    print("Your name is: "..inpstr)
end
