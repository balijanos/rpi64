function setup()
	print("Press SHIFT+ESC to abort program")
end

function draw()
    print("\r",string.format("Mouse is at x:%s y:%s",mouse.x,mouse.y))
end

function cleanup()
    print("Ok")
end

