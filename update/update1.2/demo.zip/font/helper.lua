--------------------------------
-- RPI-64 SPF 
-- Sprite Font Library Helper 
--------------------------------
bit = require "bit32"

local M = {}
          
local FONT_WIDTH=16 	
local FONT_WIDTHB = 2 -- bytes	
local FONT_HEIGHT=16

function M.createFont(bitmapfile, tileW, tileH, shift) 
	local f = {}
	f.sprite = sprite(bitmapfile)
	f.sprite:setTiles(tileW,tileH)		
	f.shift = shift or 0
	-- f.sprite:setColorKey()
	return f
end

function M.text(f,x,y,s,aa,kerning,rotation,zoom,vertical)	
	local w,h = f.sprite:getTileSize()
	kerning = kerning or w
	rotation = rotation or 0
	aa = aa or false	
	zoom = zoom or 1
	if vertical then
		for i=0,string.len(s)-1 do
			f.sprite:tile(x,y+i*kerning,string.byte(s,i+1)-f.shift, rotation, aa, zoom)
		end	
	else 
		for i=0,string.len(s)-1 do
			f.sprite:tile(x+i*kerning,y,string.byte(s,i+1)-f.shift, rotation, aa, zoom)
		end	
	end
end

-- serialized picture matrix
local function mtxpos(n)
	local c = ((n-1)  % FONT_WIDTH) * FONT_WIDTHB
	local r = math.floor ((n-1) / FONT_WIDTH)
	return r * (FONT_WIDTH * FONT_WIDTHB * FONT_HEIGHT) + c + 1
end

function M.getFontBytes(charCode,isInverted,loadHeight)
	local bitfont = {}
	local rows = loadHeight or FONT_HEIGHT
	for i=0,rows-1 do
		for j=0,FONT_WIDTHB-1 do			
			local x = UDF_FONT_MATRIX[mtxpos(charCode+1) + i * FONT_WIDTH * FONT_WIDTHB + j]			
			if isInverted then
				bit.bxor(x,0xff) -- invert B/W font
			end			
			table.insert(bitfont,x)
		end
	end
	for i=rows-1,FONT_HEIGHT-1 do
		for j=0,FONT_WIDTHB-1 do			
			local x = 0			
			if isInverted then
				bit.bxor(x,0xff) -- invert B/W font
			end			
			table.insert(bitfont,x)
		end
	end
	return bitfont
end

return M