local menuId = 1
local menuCnt = 6
local mainMenu = {
	{ name = "Basic drawing", script="demo/BasicDrawing.lua"},
	{ name = "Using sprites", script="demo/UsingSprites.lua"},	
	{ name = "Displaying text", script="demo/DisplayText.lua"},
	{ name = "Handling inputs", script="demo/HandlingInput.lua"},
	{ name = "Sound and music", script="demo/SoundMusic.lua"},
	{ name = "Simple physics", script="demo/SimplePhysics.lua"},
}
local execDemo = nil
local done = false
local skip = nil

math.randomseed( os.time() )

local function kbdHandler()	
	local selectedId = nil
	-- Handle keyboard events.    
    if keyboard.pressed['up'] then
		menuId = menuId - 1
		if (menuId<1) then menuId = menuCnt end
    elseif keyboard.pressed['down'] then
		menuId = menuId + 1
		if (menuId>menuCnt) then menuId = 1 end	
    elseif keyboard.pressed['return'] then
		selectedId = menuId
	elseif keyboard.pressed['space'] then
		selectedId = 0
	elseif keyboard.pressed['s'] then
		selectedId = -1
	elseif keyboard.pressed['q'] then
		done = true
	end
	keyboard.pressed={}
	return selectedId
end

local function drawMainMenu()
	background(0,0,0,0)
	fill(150,20,150)
	text(260,HEIGHT-50,"--- RPI-64 v1.2 DEMO ---")	
	sprite("gfx/rpi.png",5,HEIGHT-80,0,true) 
	sprite("gfx/rpi.png",WIDTH-65,HEIGHT-80,0,true) 	
	for k,v in pairs(mainMenu) do	
		if menuId==k then
			fill(200,200,20,50)
		else
			fill(100,200,200)
		end
		text(310,HEIGHT-100-50*k,v.name) 
	end
	fill(150,20,150)
	text(100,10,"Arrow keys - navigate     Return - run     Q - quit")	
end

function draw()
	if execDemo then
		drawDemo(skip)
		skip = nil
		local m = kbdHandler()
		if m==0 then
			cleanupDemo()
			execDemo=nil
		elseif m==-1 then
			skip = true
		end
		fill(150,20,150)
		text(100,10,"Press 'S' to skip current or SPACE to return to main menu")
	else 
		drawMainMenu()
		local m = kbdHandler()
		if done then return 1 end
		if m and m>0 then
			execDemo = m 
			dofile(mainMenu[m].script)
			setupDemo()
		end
	end
end

function setup()
end
function cleanup()
end
