-----------------------
-- sound demo library -
-----------------------

NOTES = {}
NOTES["C"]	= 0
NOTES["C#"] = 1
NOTES["D"] 	= 2
NOTES["D#"] = 3
NOTES["E"] 	= 4
NOTES["F"] 	= 5
NOTES["F#"] = 6
NOTES["G"] 	= 7
NOTES["G#"] = 8
NOTES["A"] 	= 9
NOTES["A"] 	= 10
NOTES["B"] 	= 11

demosong = {
		{"A", 4, 8},			-- mar
		{"G", 4, 8},			-- ry
		{"F", 4, 8},			-- had
		{"G", 4, 8},			-- a
		{"A", 4, 8},			-- lit
		{"A", 4, 8},			-- tle
		{"A", 4, 2},			-- lamb
		{"G", 4, 8},			-- lit
		{"G", 4, 8},			-- tle
		{"G", 4, 2},			-- lamb
		{"A", 4, 8},			-- lit
		{"C", 4, 8},			-- tle
		{"C", 4, 2},			-- lamb
		{"A", 4, 8},			-- mar
		{"G", 4, 8},			-- ry
		{"F", 4, 8},			-- had
		{"G", 4, 8},			-- a
		{"A", 4, 8},			-- lit
		{"A", 4, 8},			-- tle
		{"A", 4, 2},			-- lamb
		{"G", 4, 8},			-- fleece
		{"G", 4, 8},			-- was
		{"A", 4, 8},			-- white
		{"G", 4, 8},			-- as
		{"F", 1, 1},			-- snow	
}