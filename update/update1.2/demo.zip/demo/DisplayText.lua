local spf = require "font.helper"

function setupDemo()
	background(0,0,0,0)	
	dofile("font/speccyfont.lua")
end

local function showTitle(x,s)
	fill(0, 0, 0, 1)
	rect(0, HEIGHT-40, WIDTH, HEIGHT-60)
	fill(220,220,220,255)
	text(x,HEIGHT-40,s)	
	fill(100,150,200,128)
	text(270,HEIGHT-20,"Displaying text on screen")
end

local sstart=timer()
local sleep=8000
local level = 1
local maxlevel = 3
                                                                                    
local tick = 0 
local sFont1 = spf.createFont( "font/font1.png", 10, 10, 32)	-- 10 chars in 10 rows, first char is #32

local rot = 0

function drawDemo(skip)
	if timer()-sstart>sleep or skip then
		sstart = timer()
		level = level + 1
		if level>maxlevel then level = 1 end
		background(0,0,0,0)	
		tick = 0 
		rot = 0
	else
		local zz = (timer()-sstart)/10
		if level==1 then 
			showTitle(zz,"SIMPLE TEXT")
			
			fill(180,180,180,180)
			
			text(100,450,"Normal text",false)
			
			text(100,400,"Bold text",false)
			text(102,400,"Bold text",false)
			
			fill(100, 100, 100, 100)
			rect(80, 280, 200, 60)
			fill(30,40,50,60)
			text(101,299,"Shadowed text",false)			
			fill(180,180,180,180)
			text(100,300,"Shadowed text",false)			
			
			fill(180,180,180,180)
			
			text(100,200,"Condensed text (smaller kerning)",false, 8)
			
			text(100,150,"Wide text (extra kerning)",false, 20)
		elseif level==2 then 
			showTitle(zz,"USER DEFINED CHARS")
			tick = tick + 0.2
			if tick>16 then tick=1 end
			for i=0,255 do
				setfont(i, spf.getFontBytes(i,true,math.floor(tick)))
			end
			
			fill(0, 0, 0, 1)
			rect(0, 300, WIDTH, 100)
			fill(110,120,180,180)
			text(200,350,"This is the UDF font",true)
			fill(100,80,90,100)
			text(50,250,"This is the UDF font with extra kerning",true,18)
			
		elseif level==3 then 
			showTitle(zz,"SPRITE BASED CHARS")
			
			fill(100, 100, 100, 100)
			rect(20, 40, WIDTH-40, HEIGHT-100)
			
			sFont1.sprite:setColorKey()			
			spf.text(sFont1,100,450,"Hello World!",false, 50,0)
			spf.text(sFont1,150,400,"Hello World!",false, 50,-15,1.25)			
			
			
			spf.text(sFont1,100,120,"Hello",false, 36,90,0.75,true)
			spf.text(sFont1,700,250,"World",false, -36,-90,0.75,true)
			
		end		
	end
end

function cleanupDemo()
end
