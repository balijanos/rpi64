function setupDemo()
	background(0,0,0,0)	
end

local function showTitle(x,s)
	fill(0, 0, 0, 1)
	rect(0, HEIGHT-40, WIDTH, HEIGHT-60)
	fill(220,220,220,255)
	text(x,HEIGHT-40,s)	
	fill(100,150,200,128)
	text(290,HEIGHT-20,"Basic Drawing demo")
end

local sstart=timer()
local sleep=8000
local level = 1
local maxlevel = 7

function drawDemo(skip)
	if timer()-sstart>sleep or skip then
		sstart = timer()
		level = level + 1
		if level>maxlevel then level = 1 end
		background(0,0,0,0)	
	else
		local zz = (timer()-sstart)/10
		if level==1 then 
			showTitle(zz,"PIXELS")
			for i=1,150 do
				putpixel(math.random(WIDTH),50+math.random(HEIGHT-100),math.random(255),math.random(255),math.random(255),math.random(255))		
			end
		elseif level==2 then 
			showTitle(zz,"LINES")
			fill(math.random(255),math.random(255),math.random(255),math.random(255))
			line(math.random(WIDTH/2),50+math.random(HEIGHT/2-50),math.random(WIDTH),50+math.random(HEIGHT-100))			
		elseif level==3 then 
			showTitle(zz,"TRIANGLES")
			filled(math.random(0,1)==1)
			fill(math.random(255),math.random(255),math.random(255),math.random(255))
			triangle(
					math.random(WIDTH),50+math.random(HEIGHT-100),
					math.random(WIDTH),50+math.random(HEIGHT-100),
					math.random(WIDTH),50+math.random(HEIGHT-100)
			)			
		elseif level==4 then 
			showTitle(zz,"RECTANGLES")
			filled(math.random(0,1)==1)
			fill(math.random(255),math.random(255),math.random(255),math.random(255))
			local x = math.random(WIDTH/2)
			local y = 50+math.random(HEIGHT/2-50)			
			rect(x,y,math.random(WIDTH-x),50+math.random(HEIGHT-100-y))
		elseif level==5 then
			showTitle(zz,"ELLIPSES")
			filled(math.random(0,1)==1)
			fill(math.random(255),math.random(255),math.random(255),math.random(255))
			local x = math.random(WIDTH)
			local y = HEIGHT/3 + math.random(2*HEIGHT/3)-100
			ellipse( x, y, math.random(WIDTH-x)/2, math.random(math.min(HEIGHT-y,y)/2))
		elseif level==6 then
			showTitle(zz,"ARCS")			
			fill(math.random(255),math.random(255),math.random(255),math.random(255))
			local x = math.random(WIDTH)
			local y = HEIGHT/3 + math.random(2*HEIGHT/3-100)
			arc( x, y, math.random(math.min(math.max(HEIGHT-y,10),y)/2), math.random(360), math.random(360))
		elseif level==7 then
			showTitle(zz,"POLYGONS")	
			local n = 4 + math.random(6)
			local xv = {}
			local yv = {}
			for i=1,n do
				xv[i] = math.random(WIDTH)
				yv[i] = 50 + math.random(HEIGHT-100)
			end
			filled(math.random(0,1)==1)
			fill(math.random(255),math.random(255),math.random(255),math.random(255))
			polygon(xv,yv)
		end
		filled(true)
	end
end

function cleanupDemo()
end
