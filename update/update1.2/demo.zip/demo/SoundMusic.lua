require "audio"

function setupDemo()
	background(0,0,0,0)	
	dofile("demo/sound/snddemo1.lua")
	snd_setup()
end

local function showTitle(x,s)
	fill(0, 0, 0, 1)
	rect(0, HEIGHT-40, WIDTH, HEIGHT-60)
	fill(220,220,220,255)
	text(x,HEIGHT-40,s)	
	fill(100,150,200,128)
	text(220,HEIGHT-20,"Sound a music demonstration")
end

local sstart=timer()
local sleep=8000
local level = 1
local maxlevel = 5
                                                                                  
function drawDemo(skip)
	if timer()-sstart>sleep or skip then
		sstart = timer()
		snd_cleanup()
		level = level + 1
		if level>maxlevel then level = 1 end
		dofile("demo/sound/snddemo"..level.. ".lua")
		snd_setup()
		background(0,0,0,0)	
		done = 0
	else
		local zz = (timer()-sstart)/10
		-- fill(0, 0, 0, 1)
		-- rect(0, 40, WIDTH, HEIGHT-100)
		if level==1 then 
			showTitle(zz,"SAMPLE PLAYBACK")								
		elseif level==2 then 
			showTitle(zz,"SONG PLAYBACK (OGG)")	
		elseif level==3 then 
			showTitle(zz,"SIMPLE TONES")
		elseif level==4 then 
			showTitle(zz,"MULTICHANNEL TONES")
		elseif level==5 then 
			showTitle(zz,"TONE GENERATOR")
		end		
		
		snd_draw()
		
	end
end

function cleanupDemo()
	snd_cleanup()
end
