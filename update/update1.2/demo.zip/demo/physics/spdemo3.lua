local sp = require "spl.helper"

-- world objcets
local space = nil	
local ground = nil
local object = nil

function sp_setup()	
	-- space
	space = sp.createSpace{	iter = 10, dim = 10, count = 10, gravity = {0, -700} }	
	-- ground
	sp.addSandbox(space, {0,60,WIDTH,60,0}, {colltype=1} )
	-- object			
	object = sp.addCircle(space, {
			cx = WIDTH/2,
			cy = HEIGHT-180,
			radius = 40,
			mass = 20,
			elasticity = 0.6,
			friction = 0.1,
			color = {200,200,200,255},
			colltype = 2
		}
	)

	
	space:addCollisionHandler( 1,2, 
		function() 
			object.color = {100+math.random(155),100+math.random(155),100+math.random(155),100+math.random(155)}
			return true
		end
	)

end

function sp_draw() 
	-- draw a circle object
	filled(true)
	sp.drawBall(object)	
	space:step(1/60)	
end

function sp_cleanup()
	space:removeCollisionHandler(1,2)
end
