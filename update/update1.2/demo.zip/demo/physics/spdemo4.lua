local sp = require "spl.helper"

-- world objcets
local demoSpace = nil	
local ground = nil
local object = nil


local collinfo = ""

-- return false to avoid automated collision handling
local function BeginCollision(arb)		
	collinfo = "BEGIN"
	return true
end

-- query arbiter
local function PreSolveCollision(arb)		
	collinfo = "PRESOLVE"
	local A,B = arb:getShapes()
	local BodyA = A:getBody()
	local BodyB = B:getBody()
	
	BodyA:setAngularVelocity(-10)
	BodyB:setAngularVelocity(10)
	return true
end

local function PostSolveCollision(arb)		
	collinfo = "POSTSOLVE"
end

local function SeparateCollision(arb)		
	collinfo = "SEPARATE"
end


function sp_setup()	
	-- demoSpace
	demoSpace = sp.createSpace{	iter = 10, dim = 10, count = 10, gravity = {0, -500} }	
	-- ground
	sp.addSandbox(demoSpace, {0,60,WIDTH,60,0}, {friction = 0.6, colltype=1} )
	-- object			
	object1 = sp.addCircle(demoSpace, {
			cx = WIDTH/3,
			cy = HEIGHT-150,
			radius = 40,
			mass = 30,
			elasticity = 0.5,
			friction = 0.6,
			color = {200,200,200,255},
			colltype = 2
		}
	)
	object1.body:setVelocity(150,0)

	object2 = sp.addCircle(demoSpace, {
			cx = 2*WIDTH/3,
			cy = HEIGHT-150,
			radius = 40,
			mass = 30,
			elasticity = 0.5,
			friction = 0.6,
			color = {200,200,200,255},
			colltype = 3
		}
	)
	object2.body:setVelocity(-150,0)
	
	demoSpace:addCollisionHandler( 2,3, BeginCollision, PreSolveCollision, PostSolveCollision, SeparateCollision )

end

function sp_draw() 
	filled(false)
	-- draw a circle object
	sp.drawBall(object1)
	sp.drawBall(object2)
	
	fill(100,100,100,100) 
	text(10,60, "INFO: "..collinfo) 
	
	demoSpace:step(1/60)	
	filled(true)
end

function sp_cleanup()
	demoSpace:removeCollisionHandler(2,3)
end
