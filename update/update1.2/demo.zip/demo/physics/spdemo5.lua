local sp = require "spl.helper"

-- world objcets
local demoSpace = nil	
local ground = {}
local objects = {}
local joints = {}

local GRND = 90
local GRID = 999
local groundVects = {
	{GRND,       HEIGHT-GRND,   WIDTH-GRND, HEIGHT-GRND,  0},	-- top
	{GRND,       GRND*4,        GRND,       HEIGHT-GRND,  0},   -- left
	{WIDTH-GRND, GRND*4,        WIDTH-GRND, HEIGHT-GRND,  0},   -- right
	-- bottom
	{GRND,       GRND*4,        WIDTH/5, GRND,        0},		
	{WIDTH/5,    GRND,       	2*WIDTH/5, 55,         0},		
	{2*WIDTH/5,    55,       	3*WIDTH/5, 55,         0},		
	{3*WIDTH/5,  55,       		4*WIDTH/5, GRND,       0},	
	{4*WIDTH/5,  GRND,     		WIDTH-GRND,   GRND*4,  0}, 				
}

function Coll_CircleVsCircle(arb,func)	
	local joint,idx = sp.findJoint(joints,objects[2].body,objects[3].body)
	if joint then
		sp.removeJoint(joint.space,joint.id)
		table.remove(joints,idx)
	end
	return true
end

function Coll_BoxVsCircle(arb)
	local joint,idx = sp.findJoint(joints,objects[1].body,objects[2].body)
	if joint then
		sp.removeJoint(joint.space,joint.id)
		table.remove(joints,idx)
	end
	return true
end

function sp_setup()	
	-- demoSpace
	demoSpace = sp.createSpace{	iter = 10, dim = 20, count = 1000, gravity = {0, -600} }	
	-- demoSpace:addCollisionHandler(1,GRID)	
	-- ground
	local tt = {radius=20,elasticity=1,friction=1,colltype=GRID}
	for k,v in ipairs(groundVects) do	
		table.insert( ground, sp.addSandbox(demoSpace, v , tt )) 
	end
	-- add objects
	local rad = 20
	local o1 = sp.addBox(demoSpace,{cx=WIDTH/4,cy=HEIGHT-2*GRND,r=rad,color={100,200,200,255},elasticity=1,friction=1,mass=10,colltype=1})
	local o2 = sp.addCircle(demoSpace,{cx=WIDTH/4+2*rad,cy=HEIGHT-4*GRND,radius=rad,color={200,100,200,255},elasticity=1,friction=1,mass=5,colltype=2})
	local o3 = sp.addCircle(demoSpace,{cx=WIDTH/4-2*rad,cy=HEIGHT-4*GRND,radius=1.5*rad,color={200,200,100,255},elasticity=1,friction=1,mass=10,colltype=3})	
	local o4 = sp.addCircle(demoSpace,{cx=3*WIDTH/5,cy=HEIGHT-2*GRND,radius=2*rad,color={120,240,60,255},elasticity=1,friction=1,mass=5,colltype=4})	
	table.insert( objects, o1 )
	table.insert( objects, o2 )
	table.insert( objects, o3 )
	table.insert( objects, o4 )
	table.insert( joints, sp.createJoint(demoSpace, {obj1=o1,obj2=o2, x=WIDTH/4+rad, y=HEIGHT-3*GRND, maxforce=5000, bias=0.1, color={100,200,100,100} }) )
	table.insert( joints, sp.createJoint(demoSpace, {obj1=o2,obj2=o3, x=WIDTH/4-rad, y=HEIGHT-3*GRND, maxforce=5000, bias=0.1, color={200,100,220,160} }) )			
	demoSpace:addCollisionHandler(1,4,Coll_BoxVsCircle)
	demoSpace:addCollisionHandler(2,4,Coll_CircleVsCircle)
end

function drawSegmentShape(shape)	
	local r = shape:getRadius()
	local ax, ay = shape:getA()
	local bx, by = shape:getB()
	local w = math.abs(ax - bx)
	local h = math.abs(ay - by)

	if r == 0 then r = 1 end
	-- print(r+2,w,h)
	line(r+2, r+2, w, h)
	arc(r+2, r+2, r, 0, 180)
	arc(w+r+2, h+r+2, r, 0, 180)
end

function sp_draw() 	
	filled(false)
	-- draw ground
	fill(100,100,200,100) 
	for k,r in ipairs(groundVects) do				
		local a,b,c,d = unpack(r)
		line(a,b,c,d)
	end	
	-- draw objects
	fill(200,100,100,100) 
	sp.drawBox(objects[1]) 			
	sp.drawBall(objects[2])	
	sp.drawBall(objects[3])	
	sp.drawBall(objects[4])
	-- draw joints
	for k,v in ipairs(joints) do
		sp.drawJoint(v)
	end
	-- update world	
	demoSpace:step(1/50)	
	filled(true)
end

function sp_cleanup()		
	demoSpace:removeCollisionHandler(1,4)
	demoSpace:removeCollisionHandler(2,4)
end
