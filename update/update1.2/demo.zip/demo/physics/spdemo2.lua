local sp = require "spl.helper"

-- world objcets
local space = nil	
local ground = nil
local object = nil

function sp_setup()	
	-- space
	space = sp.createSpace{	iter = 10, dim = 10, count = 10, gravity = {0, -500} }	
	-- ground
	sp.addSandbox(space, {0,60,WIDTH,60,0}, {friction=0.9} )
	-- object			
	object = sp.addCircle(space, {
			cx = WIDTH/2,
			cy = HEIGHT-150,
			radius = 40,
			mass = 10,
			elasticity = 0.4,
			friction = 0.6,
			color = {200,200,200,255}	
		}
	)
	object.body:setVelocity(100,100)
	object.body:setAngle(math.pi/4)
	object.body:setAngularVelocity(10)

end

function sp_draw() 
	-- draw a circle object
	filled(false)
	sp.drawBall(object)	
	space:step(1/60)	
	filled(true)
end

function sp_cleanup()
end
