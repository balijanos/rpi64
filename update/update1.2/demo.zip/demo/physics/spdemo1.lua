local sp = require "spl.helper"
-- world objcets
local space = nil	
local ground = nil
local object = nil

function sp_setup()	
	-- space
	space = sp.createSpace{	iter = 10, dim = 10, count = 10, gravity = {0, -600} }	
	-- ground
	sp.addSandbox(space, {0,60,WIDTH,60,0})
	-- object			
	object = sp.addCircle(space, {
			cx = WIDTH/2,
			cy = HEIGHT-150,
			radius = 40,
			mass = 30,
			elasticity = 0.5,
			friction = 0.5,
			color = {200,200,200,255}	
		}
	)

end

function sp_draw() 
	-- draw a circle object
	filled(true)
	sp.drawBall(object)	
	space:step(1/60)	
end

function sp_cleanup()
end
