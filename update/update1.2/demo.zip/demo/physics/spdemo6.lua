local sp = require "spl.helper"

-- world objcets
local demoSpace = nil	
local ground = {}
local objects = {}


local GRND = 80
local GRID = 999
local groundVects = {
	{GRND,       HEIGHT-GRND,   WIDTH-GRND, HEIGHT-GRND,  0},	-- top
	{GRND,       GRND*4,        GRND,       HEIGHT-GRND,  0},   -- left
	{WIDTH-GRND, GRND*4,        WIDTH-GRND, HEIGHT-GRND,  0},   -- right
	-- bottom
	{GRND,       GRND*4,        WIDTH/5, GRND,        0},		
	{WIDTH/5,    GRND,       	2*WIDTH/5, 55,         0},		
	{2*WIDTH/5,    55,       	3*WIDTH/5, 55,         0},		
	{3*WIDTH/5,  55,       		4*WIDTH/5, GRND,       0},	
	{4*WIDTH/5,  GRND,     		WIDTH-GRND,   GRND*4,  0}, 				
}

function CollHandler(arb,func)	
	local a,b = sp.findArbiter(objects,arb)
	if a and b then	
		local o1 = objects[a]
		local o2 = objects[b]
		local c = o1.color
		o1.color = o2.color
		o2.color = c
	end
	return true
end

local sstart = timer()
local balls = 0
local rad = 23	-- ball radius
local ballsprite = nil
local PIDEV = 180 / math.pi
local MAXBALL = 50
local DELAY = 300

local function addball()
	if balls<MAXBALL then 
		local o = sp.addCircle(demoSpace,{cx=WIDTH/3+math.random(WIDTH/3),cy=HEIGHT-150,radius=rad-2,color={200,100,200,255},elasticity=0.7,friction=0.7,mass=20,colltype=1})	
		table.insert( objects, o )
		balls = balls + 1
	end
end

local function drawball(ball)	
	local x,y = ball.body:getPosition()
	local r = ball.body:getAngle() * PIDEV
	ballsprite:draw(x-ball.radius,y-ball.radius,r)
	-- sp.drawBall(ball)
end

function sp_setup()	
	-- demoSpace
	demoSpace = sp.createSpace{	iter = 10, dim = 20, count = 1000, gravity = {0, -1000} }		
	-- ground
	local tt = {radius=20,elasticity=1,friction=1,colltype=GRID}
	for k,v in ipairs(groundVects) do	
		table.insert( ground, sp.addSandbox(demoSpace, v , tt )) 
	end
	-- add objects
	addball()	
	ballsprite = sprite("gfx/ball.png")
end

function sp_draw() 	
	filled(false)
	-- draw ground
	fill(100,100,200,100) 
	for k,r in ipairs(groundVects) do				
		local a,b,c,d = unpack(r)
		line(a,b,c,d)
	end	
	fill(200,100,100,100) 
	-- draw objects
	if timer()-sstart > DELAY and balls<MAXBALL then
		addball()
		sstart = timer()
	end	
	for i=1,balls do
		drawball(objects[i])
	end
	-- update world	
	demoSpace:step(1/50)	
	filled(true)
end

function sp_cleanup()		
end
