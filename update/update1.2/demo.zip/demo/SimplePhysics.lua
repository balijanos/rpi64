function setupDemo()
	background(0,0,0,0)	
	dofile("demo/physics/spdemo2.lua")
	sp_setup()
end

local function showTitle(x,s)
	fill(0, 0, 0, 1)
	rect(0, HEIGHT-40, WIDTH, HEIGHT-60)
	fill(220,220,220,255)
	text(x,HEIGHT-40,s)	
	fill(100,150,200,128)
	text(220,HEIGHT-20,"Simple physics engine demonstration")
end

local sstart=timer()
local sleep=8000
local level = 2
local maxlevel = 6
                                                                                  

function drawDemo(skip)
	if timer()-sstart>sleep+500*level or skip then
		sstart = timer()
		sp_cleanup()
		level = level + 1
		if level>maxlevel then level = 2 end
		dofile("demo/physics/spdemo"..level.. ".lua")
		sp_setup()
		background(0,0,0,0)	
	else
		local zz = (timer()-sstart)/10
		fill(0, 0, 0, 1)
		rect(0, 40, WIDTH, HEIGHT-100)
		if level==2 then 
			showTitle(zz,"SPACE GRAVITY VELOCITY")				
		elseif level==3 then 
			showTitle(zz,"COLLISION DETECTION")	
		elseif level==4 then 
			showTitle(zz,"COLLISION HANDLING")
		elseif level==5 then 
			showTitle(zz,"JOINTS")
		elseif level==6 then 
			showTitle(zz,"COMBINED WITH SPRITE")
		end		
		
		sp_draw()
		
	end
end

function cleanupDemo()
	sp_cleanup()
end
