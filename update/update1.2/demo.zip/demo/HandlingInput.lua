local level = 1
local maxlevel = 3

function setupDemo()
	background(0,0,0,0)		
end

local function showTitle(s)	
	fill(100,150,200,128)
	text(220,HEIGHT-20,"KEYBOARD MICE JOYSTICK DEMONSTARTION")	
end

local keyp = ""
local keyr = ""

local cell_size = HEIGHT / 4
local colors = {}
colors = {
{r=255,g=0,b=255,a=1},
{r=0,g=0,b=255,a=1}, 
{r=255,g=0,b=0,a=1}, 
{r=0,g=255,b=0,a=1} 
}
local function map(x, in_min, in_max, out_min, out_max)
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
end

local function draw_joystick_info(joynum)
    fill(colors[joynum].r,colors[joynum].g,colors[joynum].b,colors[joynum].a);
    text(10, joynum * cell_size, string.format("# %d %s x:%d/y:%d button:%d",
        joynum, joystick[joynum].name,
        joystick[joynum].x, joystick[joynum].y,
        joystick[joynum].button));

    dot_x, dot_y = 0;
    dot_x = map(joystick[joynum].x, 32767, -32767, HEIGHT, 0) + WIDTH / 4;
    dot_y = map(joystick[joynum].y, 32767, -32767, 0, HEIGHT);
    ellipse(dot_x, dot_y, 30, 20);
end
 
                                                                             
function drawDemo(skip)
	if keyboard.pressed['s'] or skip then
		level = level + 1
		if level>maxlevel then level = 1 end
		background(0,0,0,0)			
	else		
		if level==1 then 
			fill(0, 0, 0, 1)
			rect(0, 40, WIDTH, HEIGHT-100)
			showTitle("KEYBOARD")
			local s = ""
			if keyboard.state == "down" then
				for k,v in pairs(keyboard.pressed) do
					if string.len(keyp)>0 then
						s = keyp .. " + "
					else
						s = ""
					end
					keyp = s..k
				end
			elseif keyboard.state == "up" then
				keyr = keyp
				keyp = ""
			end
			fill(140,140,140,120)			
			text(200,400,"Key pressed:")
			text(200,300,"Key released:")			
			fill(200,40,40,20)
			text(370,400,keyp)
			fill(40,200,40,20)
			text(370,300,keyr)
		elseif level==2 then 
			showTitle("MOUSE")	
			if mouse.pressed['1'] then
				fill(255,40,40,20)
			else
				fill(40,40,255,20)
			end		
			if mouse.y>50 and mouse.y<HEIGHT-100 then
				ellipse(mouse.x,mouse.y,10,5) 
			end
			if mouse.pressed['2'] or mouse.pressed['3'] then
				fill(0, 0, 0, 1)
				rect(0, 40, WIDTH, HEIGHT-100)
			end
		elseif level==3 then 
			fill(0, 0, 0, 1)
			rect(0, 40, WIDTH, HEIGHT-100)
			showTitle("JOSYSTICK")
			if joystick.count == 0 then
				text(120, cell_size, string.format("No joysticks detected .. plug one in and try again!"));
			end
			for jn = 1, joystick.count, 1 do
				draw_joystick_info(jn);
			end 
		end		
	end
	if keyboard.pressed['space'] then
		keyboard.pressed = {}
		keyboard.pressed['space'] = 1
	else
		keyboard.pressed = {}
	end
end

function cleanupDemo()	
end
