function setupDemo()
	background(0,0,0,0)	
end

local function showTitle(x,s)
	fill(0, 0, 0, 1)
	rect(0, HEIGHT-40, WIDTH, HEIGHT-60)
	fill(220,220,220,255)
	text(x,HEIGHT-40,s)	
	fill(100,150,200,128)
	text(270,HEIGHT-20,"Basic sprite engine demo")
end

local sstart=timer()
local sleep=8000
local level = 1
local maxlevel = 4

local image = sprite("gfx/luna.png")
local expl = sprite("gfx/explosion.png")  
expl:setTiles(5,5)
local ew,eh = expl:getTileSize()
local ball = sprite("gfx/ball.png") 
local bx,by = 250, 200
local dizzy = sprite("gfx/dizzy.png")
dizzy:setTiles(8,6)	
local dw,dh = dizzy:getTileSize()
local anim = -1
local animspeed = 3
local tick = animspeed + 1
local zoom = 0.1


function drawDemo(skip)
	if timer()-sstart>sleep or skip then
		sstart = timer()
		level = level + 1
		if level>maxlevel then level = 1 end
		background(0,0,0,0)	
		bx,by = 250, 200
		tick = animspeed + 1
		zoom = 0.1
	else
		local zz = (timer()-sstart)/10
		if level==1 then 
			showTitle(zz,"IMAGES")
			image:draw(250,200)
			ball:draw(bx,by)
			bx = bx + 1
			by = by + 0.5			
		elseif level==2 then 
			showTitle(zz,"TILES")
			fill(0, 0, 0, 1)
			rect(0, 50, WIDTH, HEIGHT-100)
			for i=0,7 do
				dizzy:tile(250+i*40,HEIGHT-100-zz/4,i)
			end
			for i=0,7 do
				dizzy:tile(250+i*40,50+zz/4,i+40)
			end
		elseif level==3 then 
			showTitle(zz,"ANIMATION")					
			if tick > animspeed then
				anim = anim + 1
				if anim > 7 then anim = 0 end
				fill(0, 0, 0, 1)
				rect(0, 200, WIDTH, 200)
				-- dizzy:setColorKey()
				dizzy:tile(340,300,anim)
				dizzy:tile(420,300,anim+40)
				dizzy:tile(zz/3,250,anim+16)				
				dizzy:tile(WIDTH-dh-zz/3,250,anim+8)
				tick = 0
			else
				tick = tick + 1
			end
		elseif level==4 then 
			showTitle(zz,"ZOOM AND ROTATE")
			tick = tick + 1			
			-- ball:setColorKey()
			ball:draw(380,280,tick*2,true,zoom)
			if tick > animspeed then
				anim = anim + 1
				if anim > 24 then anim = 0 end
				fill(0, 0, 0, 1)
				rect(200, 250, 150, 150)
				expl:tile(140,280,anim,-tick,true)
				fill(0, 0, 0, 1)
				rect(500, 250, 150, 150)
				expl:tile(540,280,anim,tick,true)
			end
			zoom = zoom + 0.01
		end		
	end
end

function cleanupDemo()
end
