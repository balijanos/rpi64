
local function sampleBuzz(freq, duration, sampleRate, A, B)
	local sin = math.sin
	local cos = math.cos
	local data = { }
	for i=1,duration*sampleRate do		
		local val = (cos( (i*freq/sampleRate)*math.pi/B) + sin( (i*freq/sampleRate)*math.pi/A)) * sin( (i*freq/sampleRate)*math.pi/4)
		table.insert(data,val)
	end
	return data
end

local tone = 440 -- Hz
local length = 0.5 -- sec
local sampleRate = 44100
local sample = nil
local sampledata = nil
local sound = nil
local loop = 0
local tick = 0

local _BKG = {64,64,100}
local _GRN = {0,200,0,255}
local _INK = {200,200,200,255}

local diva = { 0.5, 0.5, 0.5,   2, 2, 2,  }
local divb = { 0.5,   2,   4, 0.5, 2, 4,  }

function snd_setup() 
	audio.create()   			
end

local function gensample(n)
	sample = sampleBuzz(tone, length, sampleRate, diva[n+1],divb[n+1] )
end

function snd_draw()
	if loop==0 or tick==25 then	
		-- background(unpack(_BKG))	
		fill(unpack(_BKG))
		rect(0, 50, WIDTH, HEIGHT-100)
	    if loop<table.getn(diva) then
			gensample(loop)
		else
			loop = -1 
		end		
		sampledata = audio.sampleFromMemory(sample, sampleRate)
		local scale = 2^(1/12)
		if sound then audio.soundStop(sound) end
		sound = audio.soundLoop(sampledata, volumeL, volumeR, disparity, scale)
		loop = loop + 1	  
		tick = 0
	else		
		tick = tick + 1
		fill(unpack(_GRN))
		line(0,HEIGHT/2,WIDTH,HEIGHT/2)
		line(WIDTH/2,50,WIDTH/2,HEIGHT-100)	
		for x=1,WIDTH do
			putpixel(x,HEIGHT/2-sample[x]*40,unpack(_INK))
		end
	end	
end

function snd_cleanup()
	-- audio.soundStop(sound)
	audio.destroy()	
end

