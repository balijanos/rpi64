require "snd/song"

local function playNote(sample, note, volumeL, volumeR, disparity)
	local scale = 2^(note/12)
	local snd = audio.soundLoop(sample, volumeL, volumeR, disparity, scale)
	return snd
end

local function sampleSine(freq, duration, sampleRate)
	local data = { }
	local sin = math.sin
	local cos = math.cos
	for i = 1,duration*sampleRate do
		data[i] = sin( (i*freq/sampleRate)*math.pi*2)
	end
	return audio.sampleFromMemory(data, sampleRate)
end

local samples = {}
local volume = 0.1 -- 10%

-- TONES relative to A4 = 440 Hz
local C4 = 261.63
local C3 = 130.81

function snd_setup()
	audio.create()   			
	samples[1] = sampleSine(C4*2, 0.25, 44100)
end

local soundch = {}
local sch_count = 1
local loop = 0
local notec = table.getn(demosong)
local sstart = nil
local sleep = 0
local pause = 0
local tempo = 500 -- greater value --> slower playbeack

function snd_draw()    
	if sstart==nil or timer()-sstart > sleep then	
		loop = loop + 1
		if loop>notec then
			return -1 -- End program
		end
		
		if sstart and soundch[1] then audio.soundStop(soundch[1]) end
		-- play note or pause
		local note = NOTES[demosong[loop][1]]
		sleep = tempo / demosong[loop][2]								
		if pause>-1 then
			soundch[1] = playNote(samples[1],note,volume,volume)	
			text(130+loop*20,100, demosong[loop][1])										
		else
			text(130+loop*20,80, demosong[loop][3])					
		end			
		
		if pause>-1 then
			pause = - tempo / demosong[loop][3]	
			loop = loop - 1 -- play pause next			
		else
			sleep = -1 * pause
			pause = 1
		end
		sstart = timer()
	end	
end

function snd_cleanup()
	if sstart and soundch[1] then audio.soundStop(soundch[1]) end	
	audio.destroy()	
end
