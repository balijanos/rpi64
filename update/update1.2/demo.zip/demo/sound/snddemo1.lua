function snd_setup()
    audio.create()
    -- load and play a sample:
    sample = audio.sampleFromFile("snd/sample.wav")
    if sample then audio.soundPlay(sample) end
end

function snd_draw()
	fill(100,150,200,128)
	text(220,300,"Playing sample 'sample.wav'")
end

function snd_cleanup()
    audio.destroy()
end
