package.loaded.demo = nil
require "demo"
